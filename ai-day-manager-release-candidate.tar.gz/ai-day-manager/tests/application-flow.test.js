import assert from 'node:assert/strict';
import test from 'node:test';
import { createApplication } from '../dist/application/bootstrap.js';

const user='user-1';
const day='2026-10-05';

test('natural language task -> intent -> persisted task -> planned block', async()=>{
  const app=createApplication();
  const result=await app.handleNaturalLanguage(user,'Ich muss heute 45 Minuten Steuerunterlagen machen.',day);
  assert.equal(result.action,'CREATED_TASK');
  assert.equal(result.task?.estimatedDurationMinutes,45);
  assert.ok(result.plan?.blocks.some(b=>b.taskId===result.task.id));
});

test('natural language fixed event -> event -> replanning', async()=>{
  const app=createApplication();
  await app.handleNaturalLanguage(user,'Ich muss heute 60 Minuten Projektarbeit machen.',day);
  const result=await app.handleNaturalLanguage(user,'Morgen um 14 habe ich ein Bewerbungsgespräch.',day);
  assert.equal(result.action,'CREATED_EVENT');
  assert.equal(result.event?.startTime,'2026-10-06T14:00:00.000Z');
});

test('recalculate intent recomputes current state', async()=>{
  const app=createApplication();
  await app.handleNaturalLanguage(user,'Heute 30 Minuten E-Mails beantworten.',day);
  const result=await app.handleNaturalLanguage(user,'Neu planen.',day);
  assert.equal(result.action,'RECALCULATED');
  assert.ok(result.plan);
});

test('critical overlapping P1 events are not silently changed', async()=>{
  const app=createApplication();
  const a=await app.handleNaturalLanguage(user,'Heute um 14 habe ich einen Arzttermin.',day);
  assert.equal(a.action,'CREATED_EVENT');
  const b=await app.handleNaturalLanguage(user,'Heute um 14 habe ich ein Bewerbungsgespräch.',day);
  assert.equal(b.action,'REJECTED');
});
