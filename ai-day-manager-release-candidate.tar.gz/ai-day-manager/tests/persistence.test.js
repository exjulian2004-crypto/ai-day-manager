import test from 'node:test';
import assert from 'node:assert/strict';

test('Prisma persistence integration is configured', async (t)=>{
  if(!process.env.DATABASE_URL){ t.skip('DATABASE_URL not configured; run against PostgreSQL for integration tests'); return; }
  const { prisma }=await import('../dist/persistence/prisma.js');
  const { PrismaTaskRepository }=await import('../dist/persistence/task-repository.js');
  const repo=new PrismaTaskRepository(prisma);
  const userId='integration-user';
  const task=await repo.create({userId,title:'Persistence test',priority:'P3',estimatedDurationMinutes:20,schedulingMode:'FLEXIBLE',status:'OPEN'});
  const found=await repo.get(task.id,userId);
  assert.equal(found?.title,'Persistence test');
  await prisma.task.delete({where:{id:task.id}});
  await prisma.$disconnect();
});
