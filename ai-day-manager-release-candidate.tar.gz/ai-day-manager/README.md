# AI Day Manager — Google + Microsoft Calendar OAuth + Bidirectional Sync

Included:
- Google Calendar OAuth
- Microsoft Outlook / Graph OAuth
- AES-256-GCM token encryption
- user-bound expiring OAuth state
- automatic access-token refresh
- CalendarProvider abstraction
- bidirectional event create/update/delete
- persistent local↔external event links
- duplicate suppression during planning
- autonomy-aware write-through

Autonomy:
- `SUPPORTED`: external calendars are imported read-only.
- `AUTOMATIC`: local event create/update/delete is synchronized to all connected calendars.
- `AUTONOMOUS`: same provider write-through; higher-level autonomous planning decisions remain governed by the existing planner/application policy.

External events remain protected from accidental direct mutation. A locally created event gets persistent provider links so Google and Microsoft copies do not create duplicate planner blocks.

Required environment:
```bash
PUBLIC_BASE_URL=http://localhost:3000
TOKEN_ENCRYPTION_KEY=<32-byte-hex>
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
MS_CLIENT_ID=
MS_CLIENT_SECRET=
MS_TENANT_ID=common
```

Generate key:
```bash
openssl rand -hex 32
```

Run:
```bash
npm install
npx prisma generate
npx prisma migrate dev --name calendar_bidirectional_sync
npm test
npm start
```


Conflict UI:
- Provider filter: Google / Microsoft
- Status filter: open / resolved
- Resolution filter: local wins, external wins, delete, retry, manual, skipped
- Full-text search across conflict type and reason
- Detail modal with detection/resolution timestamps, event IDs and base/local/external snapshots
- Responsive layout for desktop and mobile
- API also accepts `provider`, `status`, and `resolution` query filters

Manual conflict resolution:
- `POST /api/calendar/conflicts/:id/resolve`
- `LOCAL_WINS`, `EXTERNAL_WINS`, `MERGED`
- server-side user ownership and resolved-state checks
- selected result is written back to the external provider
- merge is deterministic and local-first: local title/time/location/isFixed, external non-empty description
- failed provider write-back creates a `WRITE_FAILED` / `RETRY` audit record

Merge preview:
- `GET /api/calendar/conflicts/:id/preview`
- shows local, external and deterministic merged values for title, description, times, location and fixed-state
- highlights fields where local and external differ
- the actual merge remains a separate POST action after user confirmation
- preview and final resolution use the same deterministic merge rules

Editable merge preview:
- Merge result fields are editable before confirmation.
- `POST /api/calendar/conflicts/:id/resolve` accepts optional `overrides` for title, description, startTime, endTime, location and isFixed.
- Server-side resolution still validates the conflict and applies the final merged values; UI values are never trusted as authorization.

Server-side merge validation:
- rejects unknown override fields and invalid types
- rejects empty/oversized titles and oversized descriptions/locations
- validates ISO-compatible start/end timestamps
- rejects end <= start and durations over 24 hours
- requires boolean `isFixed`
- preview returns a conflict version containing detectedAt + local/external snapshots
- resolve requires the same version; if conflict data changed since preview, resolution is rejected as stale and the user must reload the preview

Inline server validation:
- validation failures return structured `fieldErrors` with field/code/message
- merge preview maps those errors directly to the corresponding controls
- invalid start/end ranges highlight both time rows inline
- validation errors keep the preview open so values can be corrected without losing edits
- stale conflict versions remain non-field errors and are shown at the top of the preview

Client-side live validation:
- merge fields validate on input/change for immediate feedback
- title, description, location and start/end time rules are checked locally
- invalid time ranges mark both time fields immediately
- Merge button is disabled while client-detectable validation errors exist
- server-side validation remains authoritative and is still executed on every save attempt

Production merge safety v2:
- complete merged candidate is validated before any local or external write
- stale preview versions are checked before mutation
- conflict/link snapshot persistence is represented in Prisma schema + migration
- focused validation and regression tests cover empty/long fields, invalid time ranges, normalization, snapshot comparison and validation-before-write ordering

CI merge-safety:
- `.github/workflows/merge-safety.yml` runs on push/PR to main/master.
- Installs pinned lockfile dependencies with `npm ci`.
- Runs TypeScript typecheck.
- Runs merge validation, stale-version and atomic-write regression tests.
- `.github/workflows/prisma-schema.yml` validates and formats the Prisma schema.
- The CI intentionally does not require provider credentials or a production database for deterministic merge-safety tests.
