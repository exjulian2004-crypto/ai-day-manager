-- Calendar conflict persistence required by manual merge preview/version checks.
CREATE TYPE "CalendarProviderType" AS ENUM ('GOOGLE','MICROSOFT');
CREATE TYPE "CalendarSyncConflictType" AS ENUM ('BOTH_CHANGED','LOCAL_CHANGED_EXTERNAL_CHANGED','EXTERNAL_CHANGED_LOCAL_CHANGED','EXTERNAL_DELETED_LOCAL_CHANGED','LOCAL_DELETED_EXTERNAL_CHANGED','EXTERNAL_DELETED','WRITE_FAILED');
CREATE TYPE "CalendarSyncResolution" AS ENUM ('LOCAL_WINS','EXTERNAL_WINS','MERGED','DELETE_LOCAL','DELETE_EXTERNAL','SKIPPED','MANUAL','RETRY');

ALTER TABLE "CalendarEventLink"
  ADD COLUMN "lastSyncedAt" TIMESTAMP(3),
  ADD COLUMN "localSnapshot" JSONB,
  ADD COLUMN "externalSnapshot" JSONB,
  ADD COLUMN "localUpdatedAt" TIMESTAMP(3),
  ADD COLUMN "externalUpdatedAt" TIMESTAMP(3);

CREATE TABLE "CalendarSyncConflict" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "provider" "CalendarProviderType" NOT NULL,
  "localEventId" TEXT,
  "externalEventId" TEXT,
  "type" "CalendarSyncConflictType" NOT NULL,
  "resolution" "CalendarSyncResolution" NOT NULL DEFAULT 'SKIPPED',
  "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "resolvedAt" TIMESTAMP(3),
  "baseLocalUpdatedAt" TIMESTAMP(3),
  "baseExternalUpdatedAt" TIMESTAMP(3),
  "localSnapshot" JSONB,
  "externalSnapshot" JSONB,
  "reason" TEXT,
  CONSTRAINT "CalendarSyncConflict_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "CalendarSyncConflict_userId_detectedAt_idx" ON "CalendarSyncConflict"("userId","detectedAt");
CREATE INDEX "CalendarSyncConflict_userId_resolvedAt_idx" ON "CalendarSyncConflict"("userId","resolvedAt");
CREATE INDEX "CalendarSyncConflict_provider_externalEventId_idx" ON "CalendarSyncConflict"("provider","externalEventId");
ALTER TABLE "CalendarSyncConflict" ADD CONSTRAINT "CalendarSyncConflict_userId_fkey"
  FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
