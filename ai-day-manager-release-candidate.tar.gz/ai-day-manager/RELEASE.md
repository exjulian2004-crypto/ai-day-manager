# AI Day Manager — Release Candidate

## Local startup

1. `npm ci`
2. copy `.env.example` to `.env`
3. `docker compose up -d postgres`
4. `npm run prisma:generate`
5. `npx prisma migrate deploy`
6. `npm run typecheck`
7. `npm run test:merge`
8. `npm run dev`

## Production requirements

- PostgreSQL with automated backups
- `TOKEN_ENCRYPTION_KEY` as a 32-byte encryption secret
- `OPENAI_API_KEY` only on the server
- Google/Microsoft OAuth redirect URLs configured to the public HTTPS origin
- secure HTTPS reverse proxy
- `SESSION_COOKIE_SECURE=true`
- migration deployment before application startup
- secrets supplied through the hosting secret manager, never committed

## Release gate

The release is only considered ready after:
- dependency installation succeeds
- Prisma schema validates
- TypeScript typecheck succeeds
- merge validation suite succeeds
- application starts against a real PostgreSQL instance
- authentication and calendar OAuth smoke tests succeed
- end-to-end planning/sync/conflict tests succeed
