import type { IncomingMessage, ServerResponse } from 'node:http';
import { AuthService } from './auth-service.js';
import { prisma } from '../persistence/prisma.js';

export const auth=new AuthService(prisma);
const COOKIE='ai_day_session';

export function getCookie(req:IncomingMessage,name:string):string|undefined{
  const header=req.headers.cookie??'';
  return header.split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'='))?.slice(name.length+1);
}
export async function currentUser(req:IncomingMessage){return auth.authenticate(getCookie(req,COOKIE));}
export function setSession(res:ServerResponse,token:string){
  res.setHeader('Set-Cookie',`${COOKIE}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30*86400}`);
}
export function clearSession(res:ServerResponse){
  res.setHeader('Set-Cookie',`${COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
}
export function requireUser(user:any): asserts user is {id:string;name:string;email:string;timezone:string}{
  if(!user)throw Object.assign(new Error('Authentication required'),{statusCode:401});
}
