import { createHash, randomBytes, scrypt as scryptCb, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import type { PrismaClient } from '@prisma/client';

const scrypt=promisify(scryptCb);
const SESSION_DAYS=30;

async function hashPassword(password:string):Promise<string>{
  if(password.length<10) throw new Error('Password must be at least 10 characters');
  const salt=randomBytes(16);
  const key=await scrypt(password,salt,64) as Buffer;
  return `scrypt$${salt.toString('base64url')}$${key.toString('base64url')}`;
}
async function verifyPassword(password:string,encoded:string):Promise<boolean>{
  const [scheme,saltRaw,keyRaw]=encoded.split('$');
  if(scheme!=='scrypt'||!saltRaw||!keyRaw)return false;
  const salt=Buffer.from(saltRaw,'base64url'), expected=Buffer.from(keyRaw,'base64url');
  const actual=await scrypt(password,salt,64) as Buffer;
  return actual.length===expected.length && timingSafeEqual(actual,expected);
}
function normalizeEmail(email:string){return email.trim().toLowerCase();}
function hashToken(token:string){return createHash('sha256').update(token).digest('hex');}

export type AuthUser={id:string;name:string;email:string;timezone:string};

export class AuthService{
  constructor(private readonly db:PrismaClient){}
  async signup(email:string,password:string,name:string):Promise<{user:AuthUser;token:string}>{
    const normalized=normalizeEmail(email);
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized))throw new Error('Invalid email');
    const passwordHash=await hashPassword(password);
    const existing=await this.db.credential.findUnique({where:{email:normalized}});
    if(existing)throw new Error('An account with this email already exists');
    const user=await this.db.user.create({data:{
      name:name.trim()||normalized.split('@')[0],timezone:'Europe/Vienna',
      credential:{create:{email:normalized,passwordHash}}
    },include:{credential:true}});
    return {user:{id:user.id,name:user.name,email:normalized,timezone:user.timezone},token:await this.createSession(user.id)};
  }
  async login(email:string,password:string){
    const credential=await this.db.credential.findUnique({where:{email:normalizeEmail(email)},include:{user:true}});
    if(!credential || !(await verifyPassword(password,credential.passwordHash)))throw new Error('Invalid email or password');
    return {user:{id:credential.user.id,name:credential.user.name,email:credential.email,timezone:credential.user.timezone},token:await this.createSession(credential.userId)};
  }
  async authenticate(token:string|undefined):Promise<AuthUser|null>{
    if(!token)return null;
    const row=await this.db.session.findUnique({where:{tokenHash:hashToken(token)},include:{user:{include:{credential:true}}}});
    if(!row)return null;
    if(row.expiresAt<=new Date()){await this.db.session.delete({where:{id:row.id}});return null;}
    await this.db.session.update({where:{id:row.id},data:{lastSeenAt:new Date()}});
    return {id:row.user.id,name:row.user.name,email:row.user.credential!.email,timezone:row.user.timezone};
  }
  async logout(token:string|undefined){if(token)await this.db.session.deleteMany({where:{tokenHash:hashToken(token)}});}
  private async createSession(userId:string){
    const token=randomBytes(32).toString('base64url');
    await this.db.session.create({data:{userId,tokenHash:hashToken(token),expiresAt:new Date(Date.now()+SESSION_DAYS*86400000)}});
    return token;
  }
}
