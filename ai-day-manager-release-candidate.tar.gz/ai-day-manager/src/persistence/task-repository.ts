import type { PrismaClient, Priority as DbPriority, SchedulingMode as DbSchedulingMode, TaskStatus as DbTaskStatus } from '@prisma/client';
import type { Task, Priority, SchedulingMode } from '../domain/types.js';

function toDomain(row:any):Task {
  return {
    id:row.id,userId:row.userId,title:row.title,description:row.description ?? undefined,
    priority:row.priority as Priority,
    estimatedDurationMinutes:row.estimatedDurationMinutes,
    deadline:row.deadline?.toISOString(),
    schedulingMode:row.schedulingMode as SchedulingMode,
    status:row.status,
    preferredStart:row.preferredStart ?? undefined,
    preferredEnd:row.preferredEnd ?? undefined,
    createdAt:row.createdAt.toISOString(),updatedAt:row.updatedAt.toISOString()
  };
}

export class PrismaTaskRepository {
  constructor(private readonly db:PrismaClient){}
  async create(input:Omit<Task,'id'|'createdAt'|'updatedAt'>):Promise<Task>{
    const row=await this.db.task.create({data:{
      userId:input.userId,title:input.title,description:input.description,
      priority:input.priority as DbPriority,
      estimatedDurationMinutes:input.estimatedDurationMinutes,
      deadline:input.deadline?new Date(input.deadline):undefined,
      schedulingMode:input.schedulingMode as DbSchedulingMode,
      status:input.status as DbTaskStatus,
      preferredStart:input.preferredStart,preferredEnd:input.preferredEnd
    }});
    return toDomain(row);
  }
  async list(userId:string):Promise<Task[]>{
    const rows=await this.db.task.findMany({where:{userId},orderBy:[{priority:'asc'},{deadline:'asc'}]});
    return rows.map(toDomain);
  }
  async get(id:string,userId:string):Promise<Task|undefined>{
    const row=await this.db.task.findFirst({where:{id,userId}});
    return row?toDomain(row):undefined;
  }
  async update(id:string,userId:string,patch:Partial<Task>):Promise<Task>{
    const row=await this.db.task.updateMany({where:{id,userId},data:{
      ...(patch.title!==undefined?{title:patch.title}:{}),
      ...(patch.description!==undefined?{description:patch.description}:{}),
      ...(patch.priority!==undefined?{priority:patch.priority as DbPriority}:{}),
      ...(patch.estimatedDurationMinutes!==undefined?{estimatedDurationMinutes:patch.estimatedDurationMinutes}:{}),
      ...(patch.deadline!==undefined?{deadline:patch.deadline?new Date(patch.deadline):null}:{}),
      ...(patch.schedulingMode!==undefined?{schedulingMode:patch.schedulingMode as DbSchedulingMode}:{}),
      ...(patch.status!==undefined?{status:patch.status as DbTaskStatus}:{}),
      ...(patch.preferredStart!==undefined?{preferredStart:patch.preferredStart}:{}),
      ...(patch.preferredEnd!==undefined?{preferredEnd:patch.preferredEnd}:{}),
    }});
    if(row.count!==1) throw new Error('Task not found');
    return (await this.get(id,userId))!;
  }
}
