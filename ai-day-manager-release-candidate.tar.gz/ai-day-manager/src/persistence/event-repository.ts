import type { PrismaClient, Priority as DbPriority } from '@prisma/client';
import type { CalendarEvent, Priority } from '../domain/types.js';

function toDomain(row:any):CalendarEvent {
  return {
    id:row.id,userId:row.userId,title:row.title,description:row.description ?? undefined,
    startTime:row.startTime.toISOString(),endTime:row.endTime.toISOString(),
    location:row.location ?? undefined,priority:row.priority as Priority,isFixed:row.isFixed,
    source:row.source,preparationMinutes:row.preparationMinutes,travelMinutes:row.travelMinutes,
    createdAt:row.createdAt.toISOString(),updatedAt:row.updatedAt.toISOString()
  };
}
export class PrismaEventRepository {
  constructor(private readonly db:PrismaClient){}
  async getDay(userId:string,start:Date,end:Date):Promise<CalendarEvent[]>{
    const rows=await this.db.calendarEvent.findMany({
      where:{userId,startTime:{lt:end},endTime:{gt:start}},orderBy:{startTime:'asc'}
    });
    return rows.map(toDomain);
  }
  async create(event:CalendarEvent):Promise<CalendarEvent>{
    const row=await this.db.calendarEvent.create({data:{
      userId:event.userId,title:event.title,description:event.description,
      startTime:new Date(event.startTime),endTime:new Date(event.endTime),
      location:event.location,priority:event.priority as DbPriority,isFixed:event.isFixed,
      source:event.source,preparationMinutes:event.preparationMinutes??0,travelMinutes:event.travelMinutes??0
    }});
    return toDomain(row);
  }
  async update(id:string,userId:string,patch:Partial<CalendarEvent>):Promise<CalendarEvent>{
    const row=await this.db.calendarEvent.updateMany({where:{id,userId},data:{
      ...(patch.title!==undefined?{title:patch.title}:{}),
      ...(patch.description!==undefined?{description:patch.description}:{}),
      ...(patch.startTime!==undefined?{startTime:new Date(patch.startTime)}:{}),
      ...(patch.endTime!==undefined?{endTime:new Date(patch.endTime)}:{}),
      ...(patch.location!==undefined?{location:patch.location}:{}),
      ...(patch.priority!==undefined?{priority:patch.priority as DbPriority}:{}),
      ...(patch.isFixed!==undefined?{isFixed:patch.isFixed}:{}),
    }});
    if(row.count!==1) throw new Error('Calendar event not found');
    const found=await this.db.calendarEvent.findFirst({where:{id,userId}});
    if(!found) throw new Error('Calendar event not found');
    return toDomain(found);
  }
  async delete(id:string,userId:string):Promise<void>{
    await this.db.calendarEvent.deleteMany({where:{id,userId}});
  }
}
