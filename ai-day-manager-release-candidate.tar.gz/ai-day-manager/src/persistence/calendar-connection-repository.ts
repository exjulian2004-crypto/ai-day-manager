import type { PrismaClient, CalendarProviderType } from '@prisma/client';
import { encryptToken, decryptToken } from './token-vault.js';
export class CalendarConnectionRepository {
  constructor(private readonly db:PrismaClient){}
  async save(x:{userId:string;provider:CalendarProviderType;providerAccountId?:string;email?:string;accessToken?:string;refreshToken:string;expiresAt?:Date;scope?:string;calendarId?:string}) {
    return this.db.calendarConnection.upsert({
      where:{userId_provider:{userId:x.userId,provider:x.provider}},
      create:{userId:x.userId,provider:x.provider,providerAccountId:x.providerAccountId,email:x.email,
        accessTokenCipher:x.accessToken?encryptToken(x.accessToken):undefined,refreshTokenCipher:encryptToken(x.refreshToken),
        expiresAt:x.expiresAt,scope:x.scope,calendarId:x.calendarId},
      update:{providerAccountId:x.providerAccountId,email:x.email,
        ...(x.accessToken?{accessTokenCipher:encryptToken(x.accessToken)}:{}),
        refreshTokenCipher:encryptToken(x.refreshToken),expiresAt:x.expiresAt,scope:x.scope,calendarId:x.calendarId}
    });
  }
  async get(userId:string,provider:CalendarProviderType){
    const r=await this.db.calendarConnection.findUnique({where:{userId_provider:{userId,provider}}});
    if(!r)return null;
    return {...r,accessToken:r.accessTokenCipher?decryptToken(r.accessTokenCipher):undefined,refreshToken:decryptToken(r.refreshTokenCipher)};
  }
  async updateTokens(id:string,x:{accessToken:string;refreshToken?:string;expiresAt:Date}){
    return this.db.calendarConnection.update({where:{id},data:{
      accessTokenCipher:encryptToken(x.accessToken),
      ...(x.refreshToken?{refreshTokenCipher:encryptToken(x.refreshToken)}:{}),
      expiresAt:x.expiresAt,lastSyncAt:new Date()
    }});
  }
  async list(userId:string){return this.db.calendarConnection.findMany({where:{userId},select:{provider:true,email:true,lastSyncAt:true}});}
}
