import type { PrismaClient, PlanBlockType as DbBlock, Priority as DbPriority } from '@prisma/client';
import type { DailyPlan, PlanBlock, PlanningConflict, PlanningRecommendation, Priority } from '../domain/types.js';

export class PrismaPlanRepository {
  constructor(private readonly db:PrismaClient){}
  async replaceDay(userId:string,date:string,plan:DailyPlan):Promise<DailyPlan>{
    const day=new Date(`${date}T00:00:00.000Z`);
    await this.db.$transaction(async tx=>{
      await tx.planBlock.deleteMany({where:{userId,date:day}});
      await tx.planningConflict.deleteMany({where:{userId,date:day}});
      for(const b of plan.blocks){
        await tx.planBlock.create({data:{
          id:b.id,userId,taskId:b.taskId??null,date:day,type:b.type as DbBlock,title:b.title,
          startTime:new Date(b.startTime),endTime:new Date(b.endTime),source:b.source,
          priority:b.priority?(b.priority as DbPriority):null,locked:b.locked,reason:b.reason
        }});
      }
      for(const c of plan.conflicts){
        await tx.planningConflict.create({data:{
          userId,date:day,type:c.type,severity:c.severity,description:c.description,
          relatedBlocks:c.relatedBlocks,resolutionStatus:c.resolutionStatus
        }});
      }
    });
    return plan;
  }
  async getDay(userId:string,date:string):Promise<DailyPlan>{
    const day=new Date(`${date}T00:00:00.000Z`);
    const [blocks,conflicts]=await Promise.all([
      this.db.planBlock.findMany({where:{userId,date:day},orderBy:{startTime:'asc'}}),
      this.db.planningConflict.findMany({where:{userId,date:day}})
    ]);
    return {
      date,blocks:blocks.map((b:any)=>({
        id:b.id,taskId:b.taskId??undefined,type:b.type,title:b.title,startTime:b.startTime.toISOString(),
        endTime:b.endTime.toISOString(),source:b.source,priority:b.priority as Priority|undefined,
        locked:b.locked,reason:b.reason??undefined
      })),
      conflicts:conflicts.map((c:any)=>({
        id:c.id,type:c.type,severity:c.severity,description:c.description,
        relatedBlocks:c.relatedBlocks,resolutionStatus:c.resolutionStatus
      })),
      recommendations:[]
    };
  }
}
