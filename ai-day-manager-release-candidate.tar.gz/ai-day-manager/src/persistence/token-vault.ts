import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
function key():Buffer {
  const raw=process.env.TOKEN_ENCRYPTION_KEY?.trim();
  if(!raw || !/^[0-9a-fA-F]{64}$/.test(raw)) throw new Error('TOKEN_ENCRYPTION_KEY must be a 32-byte hex value');
  return Buffer.from(raw,'hex');
}
export function encryptToken(value:string):string {
  const iv=randomBytes(12), c=createCipheriv('aes-256-gcm',key(),iv);
  const data=Buffer.concat([c.update(value,'utf8'),c.final()]);
  return [iv,c.getAuthTag(),data].map(x=>x.toString('base64url')).join('.');
}
export function decryptToken(payload:string):string {
  const [iv,tag,data]=payload.split('.');
  if(!iv||!tag||!data) throw new Error('Invalid encrypted token');
  const d=createDecipheriv('aes-256-gcm',key(),Buffer.from(iv,'base64url'));
  d.setAuthTag(Buffer.from(tag,'base64url'));
  return Buffer.concat([d.update(Buffer.from(data,'base64url')),d.final()]).toString('utf8');
}
export function hashOAuthState(state:string){return createHash('sha256').update(state).digest('hex');}
