import type { PrismaClient, CalendarProviderType } from '@prisma/client';

export class CalendarEventLinkRepository {
  constructor(private readonly db:PrismaClient){}
  async create(x:{userId:string;localEventId:string;provider:CalendarProviderType;externalEventId:string}){
    return this.db.calendarEventLink.upsert({
      where:{localEventId_provider:{localEventId:x.localEventId,provider:x.provider}},
      create:x,update:{externalEventId:x.externalEventId}
    });
  }
  async byExternal(userId:string,provider:CalendarProviderType,externalEventId:string){
    return this.db.calendarEventLink.findFirst({where:{userId,provider,externalEventId}});
  }
  async byLocal(userId:string,localEventId:string){
    return this.db.calendarEventLink.findMany({where:{userId,localEventId}});
  }
  async updateSnapshot(id:string,data:{
    localSnapshot?:any;externalSnapshot?:any;localUpdatedAt?:Date;externalUpdatedAt?:Date;lastSyncedAt?:Date
  }){
    return this.db.calendarEventLink.update({where:{id},data});
  }
  async deleteByExternal(userId:string,provider:CalendarProviderType,externalEventId:string){
    return this.db.calendarEventLink.deleteMany({where:{userId,provider,externalEventId}});
  }
}
