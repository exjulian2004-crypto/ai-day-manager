import type { PrismaClient, AutonomyLevel as DbAutonomy } from '@prisma/client';
import type { UserPreferences } from '../domain/types.js';

export class PrismaPreferencesRepository {
  constructor(private readonly db:PrismaClient){}
  async get(userId:string):Promise<UserPreferences>{
    const row=await this.db.userPreferences.findUnique({where:{userId}});
    if(row) return {
      workStartTime:row.workStartTime,workEndTime:row.workEndTime,sleepStartTime:row.sleepStartTime,
      sleepEndTime:row.sleepEndTime,preferredBreakDurationMinutes:row.preferredBreakDurationMinutes,
      preferredDeepWorkDurationMinutes:row.preferredDeepWorkDurationMinutes,
      defaultBufferMinutes:row.defaultBufferMinutes,autonomyLevel:row.autonomyLevel as UserPreferences['autonomyLevel'],
      timezone:row.timezone
    };
    return {
      workStartTime:'08:30',workEndTime:'18:00',sleepStartTime:'23:00',sleepEndTime:'07:00',
      preferredBreakDurationMinutes:15,preferredDeepWorkDurationMinutes:90,defaultBufferMinutes:10,
      autonomyLevel:'SUPPORTED',timezone:'Europe/Vienna'
    };
  }
  async set(userId:string,p:UserPreferences):Promise<UserPreferences>{
    await this.db.user.upsert({
      where:{id:userId},create:{id:userId,name:'User',timezone:p.timezone},
      update:{timezone:p.timezone}
    });
    const row=await this.db.userPreferences.upsert({
      where:{userId},create:{userId,...p,autonomyLevel:p.autonomyLevel as DbAutonomy},
      update:{...p,autonomyLevel:p.autonomyLevel as DbAutonomy}
    });
    return {
      workStartTime:row.workStartTime,workEndTime:row.workEndTime,sleepStartTime:row.sleepStartTime,
      sleepEndTime:row.sleepEndTime,preferredBreakDurationMinutes:row.preferredBreakDurationMinutes,
      preferredDeepWorkDurationMinutes:row.preferredDeepWorkDurationMinutes,
      defaultBufferMinutes:row.defaultBufferMinutes,autonomyLevel:row.autonomyLevel as UserPreferences['autonomyLevel'],
      timezone:row.timezone
    };
  }
}
