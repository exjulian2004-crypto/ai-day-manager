import type { CalendarEvent } from '../domain/types.js';
import type { CalendarProvider } from '../services/calendar-service.js';
import { PrismaEventRepository } from '../persistence/event-repository.js';
import { CalendarEventLinkRepository } from '../persistence/calendar-event-link-repository.js';
import { prisma } from '../persistence/prisma.js';
import { getGoogleEvents,getMicrosoftEvents,createGoogleEvent,updateGoogleEvent,deleteGoogleEvent,createMicrosoftEvent,updateMicrosoftEvent,deleteMicrosoftEvent } from './external-providers.js';

type P='GOOGLE'|'MICROSOFT';

export class SyncedCalendarProvider implements CalendarProvider{
  private readonly links=new CalendarEventLinkRepository(prisma);
  constructor(private readonly local:PrismaEventRepository){}
  private async autonomy(userId:string){
    const p=await prisma.userPreferences.findUnique({where:{userId},select:{autonomyLevel:true}});
    return p?.autonomyLevel??'SUPPORTED';
  }
  private async connected(userId:string){
    return prisma.calendarConnection.findMany({where:{userId},select:{provider:true}});
  }
  async getEvents(userId:string,start:Date,end:Date){
    const local=await this.local.getDay(userId,start,end);
    const connected=await this.connected(userId);
    const results=await Promise.allSettled(connected.map(c=>c.provider==='GOOGLE'?getGoogleEvents(userId,start,end):getMicrosoftEvents(userId,start,end)));
    const external=results.flatMap(r=>r.status==='fulfilled'?r.value:[]);
    const successfulProviders=new Set<P>();
    results.forEach((r,i)=>{if(r.status==='fulfilled') successfulProviders.add(connected[i].provider);});
    const mapped:CalendarEvent[]=[];
    for(const e of external){
      const p=(e.source==='google'?'GOOGLE':'MICROSOFT') as P;
      const externalId=e.id;
      const link=await this.links.byExternal(userId,p,externalId);
      if(link) mapped.push({...e,id:link.localEventId,source:`synced:${e.source}`});
      else mapped.push(e);
    }
    // If every successfully-read linked provider copy disappeared, treat that
    // as a real external deletion. Never reconcile a provider whose read failed.
    for(const e of local){
      const links=await this.links.byLocal(userId,e.id);
      if(!links.length) continue;
      const relevant=links.filter(l=>successfulProviders.has(l.provider));
      if(relevant.length && relevant.every(l=>!external.some(x=>x.source===l.provider.toLowerCase() && x.id===l.externalEventId))){
        await this.local.delete(e.id,userId);
      }
    }
    const linkedLocalIds=new Set(mapped.filter(e=>e.source.startsWith('synced:')).map(e=>e.id));
    const refreshedLocal=(await this.local.getDay(userId,start,end)).filter(e=>!linkedLocalIds.has(e.id));
    return [...refreshedLocal,...mapped].sort((a,b)=>new Date(a.startTime).getTime()-new Date(b.startTime).getTime());
  }
  async createEvent(event:CalendarEvent){
    const saved=await this.local.create(event);
    if(await this.autonomy(event.userId)==='SUPPORTED') return saved;
    const connected=await this.connected(event.userId);
    for(const c of connected){
      try{
        const externalId=c.provider==='GOOGLE'?await createGoogleEvent(event.userId,saved):await createMicrosoftEvent(event.userId,saved);
        await this.links.create({userId:event.userId,localEventId:saved.id,provider:c.provider,externalEventId:externalId});
      }catch(err){ if(connected.length===1) throw err; }
    }
    return saved;
  }
  async updateEvent(id:string,userId:string,patch:Partial<CalendarEvent>){
    const saved=await this.local.update(id,userId,patch);
    if(await this.autonomy(userId)==='SUPPORTED') return saved;
    const links=await this.links.byLocal(userId,id);
    for(const link of links){
      if(link.provider==='GOOGLE')await updateGoogleEvent(userId,link.externalEventId,saved);
      else await updateMicrosoftEvent(userId,link.externalEventId,saved);
    }
    return saved;
  }
  async deleteEvent(id:string,userId:string){
    const links=await this.links.byLocal(userId,id);
    if(await this.autonomy(userId)!=='SUPPORTED'){
      for(const link of links){
        if(link.provider==='GOOGLE')await deleteGoogleEvent(userId,link.externalEventId);
        else await deleteMicrosoftEvent(userId,link.externalEventId);
      }
    }
    await this.local.delete(id,userId);
  }
}
