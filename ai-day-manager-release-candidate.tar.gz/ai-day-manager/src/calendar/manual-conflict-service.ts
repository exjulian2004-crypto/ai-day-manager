import { prisma } from '../persistence/prisma.js';
import { PrismaEventRepository } from '../persistence/event-repository.js';
import { CalendarEventLinkRepository } from '../persistence/calendar-event-link-repository.js';
import { ConflictRepository, snapshot } from './conflict-resolution.js';
import { updateGoogleEvent, updateMicrosoftEvent } from './external-providers.js';
import type { CalendarEvent } from '../domain/types.js';

export type Choice='LOCAL_WINS'|'EXTERNAL_WINS'|'MERGED';
export type MergeOverrides=Partial<Record<'title'|'description'|'startTime'|'endTime'|'location'|'isFixed',string|boolean|null>>;
export type ConflictVersion={detectedAt:string|Date;localSnapshot:any;externalSnapshot:any};

export function asDate(value:any,label:string){
  const d=new Date(value);
  if(!value||Number.isNaN(d.getTime()))throw new Error(`${label} ist keine gültige Zeit.`);
  return d;
}

export function validateMergeOverrides(overrides:MergeOverrides,baseMerged:any){
  const errors:Array<{field:string;code:string;message:string}>=[];
  const allowed=['title','description','startTime','endTime','location','isFixed'];
  for(const key of Object.keys(overrides)){
    if(!allowed.includes(key))errors.push({field:key,code:'UNKNOWN_FIELD',message:`Unzulässiges Merge-Feld: ${key}`});
  }

  const merged={...baseMerged,...overrides};

  if(typeof merged.title!=='string'||!merged.title.trim())
    errors.push({field:'title',code:'REQUIRED',message:'Der Titel darf nicht leer sein.'});
  else if(merged.title.length>500)
    errors.push({field:'title',code:'TOO_LONG',message:'Der Titel ist zu lang.'});

  if(merged.description!=null&&typeof merged.description!=='string')
    errors.push({field:'description',code:'INVALID_TYPE',message:'Die Beschreibung ist ungültig.'});
  else if(merged.description?.length>10000)
    errors.push({field:'description',code:'TOO_LONG',message:'Die Beschreibung ist zu lang.'});

  if(merged.location!=null&&typeof merged.location!=='string')
    errors.push({field:'location',code:'INVALID_TYPE',message:'Der Ort ist ungültig.'});
  else if(merged.location?.length>1000)
    errors.push({field:'location',code:'TOO_LONG',message:'Der Ort ist zu lang.'});

  if(typeof merged.isFixed!=='boolean')
    errors.push({field:'isFixed',code:'INVALID_TYPE',message:'„Fixiert“ muss Ja oder Nein sein.'});

  let start:Date|undefined,end:Date|undefined;
  try{start=asDate(merged.startTime,'Startzeit');}
  catch(e){errors.push({field:'startTime',code:'INVALID_TIME',message:e instanceof Error?e.message:'Startzeit ist ungültig.'});}
  try{end=asDate(merged.endTime,'Endzeit');}
  catch(e){errors.push({field:'endTime',code:'INVALID_TIME',message:e instanceof Error?e.message:'Endzeit ist ungültig.'});}

  if(start&&end){
    if(end<=start){
      errors.push({field:'startTime',code:'INVALID_RANGE',message:'Die Endzeit muss nach der Startzeit liegen.'});
      errors.push({field:'endTime',code:'INVALID_RANGE',message:'Die Endzeit muss nach der Startzeit liegen.'});
    }else if(end.getTime()-start.getTime()>24*60*60*1000){
      errors.push({field:'startTime',code:'TOO_LONG_RANGE',message:'Der Zeitraum darf höchstens 24 Stunden dauern.'});
      errors.push({field:'endTime',code:'TOO_LONG_RANGE',message:'Der Zeitraum darf höchstens 24 Stunden dauern.'});
    }
  }

  if(errors.length){
    const error:any=new Error('Die Merge-Daten sind ungültig.');
    error.code='VALIDATION_ERROR';
    error.fieldErrors=errors;
    throw error;
  }

  return {
    ...merged,
    title:merged.title.trim(),
    description:merged.description==null?'':merged.description,
    location:merged.location==null?'':merged.location,
    startTime:start!.toISOString(),
    endTime:end!.toISOString(),
    isFixed:Boolean(merged.isFixed)
  };
}

export function snapshotsEqual(a:any,b:any){
  return JSON.stringify(a??null)===JSON.stringify(b??null);
}

function mergeValues(local:any,external:any){
  return {
    title:local.title||external.title,
    description:external.description?.trim()?external.description:local.description,
    startTime:local.startTime,
    endTime:local.endTime,
    location:local.location||external.location,
    isFixed:local.isFixed
  };
}

function mergePreview(local:any,external:any){
  const fields=['title','description','startTime','endTime','location','isFixed'];
  const merged=mergeValues(local,external);
  return fields.map(field=>({
    field,
    local:local[field]??null,
    external:external[field]??null,
    merged:merged[field]??null,
    changed:JSON.stringify(local[field]??null)!==JSON.stringify(external[field]??null)
  }));
}

type Deps={
  conflicts:ConflictRepository;
  links:CalendarEventLinkRepository;
  events:PrismaEventRepository;
};

export class ManualConflictService{
  private readonly conflicts:ConflictRepository;
  private readonly links:CalendarEventLinkRepository;
  private readonly events:PrismaEventRepository;

  constructor(deps?:Partial<Deps>){
    this.conflicts=deps?.conflicts??new ConflictRepository(prisma);
    this.links=deps?.links??new CalendarEventLinkRepository(prisma);
    this.events=deps?.events??new PrismaEventRepository(prisma);
  }

  private async event(userId:string,id:string){
    const rows=await this.events.getDay(userId,new Date('1970-01-01T00:00:00.000Z'),new Date('2100-01-01T00:00:00.000Z'));
    return rows.find(x=>x.id===id)??null;
  }

  private assertFresh(c:any,local:any,expectedVersion?:ConflictVersion){
    if(!expectedVersion)return;
    const currentLocal=local?snapshot(local):null;
    const currentExternal=c.externalSnapshot??null;
    const versionTime=new Date(expectedVersion.detectedAt).getTime();
    const currentDetected=new Date(c.detectedAt).getTime();
    if(currentDetected!==versionTime||
       !snapshotsEqual(currentLocal,expectedVersion.localSnapshot)||
       !snapshotsEqual(currentExternal,expectedVersion.externalSnapshot)){
      const error:any=new Error('Der Konflikt ist veraltet. Die Daten haben sich seit der Vorschau geändert. Bitte Vorschau neu laden.');
      error.code='STALE_CONFLICT';
      throw error;
    }
  }

  async preview(userId:string,id:string){
    const c=await this.conflicts.getForUser(userId,id);
    if(!c)throw new Error('Conflict not found');
    if(c.resolvedAt)throw new Error('Conflict is already resolved.');
    if(!c.localEventId||!c.externalEventId)throw new Error('Conflict has no resolvable event pair');
    const local=await this.event(userId,c.localEventId);
    if(!local)throw new Error('Local event no longer exists');
    const external=c.externalSnapshot as any;
    return {
      conflictId:id,provider:c.provider,type:c.type,
      version:{detectedAt:c.detectedAt,localSnapshot:snapshot(local),externalSnapshot:external},
      localSnapshot:snapshot(local),externalSnapshot:external,
      fields:mergePreview(local,external)
    };
  }

  async resolve(userId:string,id:string,choice:Choice,overrides:MergeOverrides={},expectedVersion?:ConflictVersion){
    const c=await this.conflicts.getForUser(userId,id);
    if(!c)throw new Error('Conflict not found');
    if(c.resolvedAt)throw new Error('Conflict is already resolved');
    if(!c.localEventId||!c.externalEventId)throw new Error('Conflict has no resolvable event pair');

    const local=await this.event(userId,c.localEventId);
    if(!local)throw new Error('Local event no longer exists');

    // Version check happens before any write.
    this.assertFresh(c,local,expectedVersion);

    const link=await this.links.byExternal(userId,c.provider,c.externalEventId);
    if(!link)throw new Error('Calendar link no longer exists');

    const external=c.externalSnapshot as any;
    let final:CalendarEvent=local;
    let reason='User selected local version.';

    if(choice==='LOCAL_WINS'){
      final=local;
    }else if(choice==='EXTERNAL_WINS'){
      final=await this.events.update(local.id,userId,{
        title:external.title,description:external.description,
        startTime:external.startTime,endTime:external.endTime,location:external.location
      });
      reason='User selected external version.';
    }else{
      // Validate the complete final object BEFORE any local/provider write.
      const candidate=mergeValues(local,external);
      const validated=validateMergeOverrides(overrides,candidate);
      final={
        ...local,
        title:validated.title,
        description:validated.description||undefined,
        startTime:validated.startTime,
        endTime:validated.endTime,
        location:validated.location||undefined,
        isFixed:validated.isFixed,
        updatedAt:local.updatedAt
      };
      // Single local mutation only after all fields passed validation.
      final=await this.events.update(local.id,userId,final);
      reason='User selected merged version with validated manual overrides.';
    }

    try{
      if(c.provider==='GOOGLE')await updateGoogleEvent(userId,c.externalEventId,final);
      else await updateMicrosoftEvent(userId,c.externalEventId,final);
    }catch(e){
      await this.conflicts.record({
        userId,provider:c.provider,localEventId:local.id,externalEventId:c.externalEventId,
        type:'WRITE_FAILED',resolution:'RETRY',
        reason:`Manual resolution write-back failed: ${String(e)}`
      });
      throw new Error('Resolution could not be synchronized to provider');
    }

    await this.links.updateSnapshot(link.id,{
      localSnapshot:snapshot(final),
      externalSnapshot:snapshot(final),
      localUpdatedAt:new Date(final.updatedAt),
      externalUpdatedAt:new Date(final.updatedAt),
      lastSyncedAt:new Date()
    });
    await this.conflicts.resolve(c.id,choice,reason);
    return {conflictId:c.id,resolution:choice,event:final};
  }
}
