import { strict as assert } from 'node:assert';
import { validateMergeOverrides, snapshotsEqual } from './manual-conflict-service.js';

const base={
  title:'Meeting',
  description:'Description',
  startTime:'2026-10-05T10:00:00.000Z',
  endTime:'2026-10-05T11:00:00.000Z',
  location:'Office',
  isFixed:true
};

function expectFieldError(overrides:any,field:string,code:string){
  assert.throws(
    ()=>validateMergeOverrides(overrides,base),
    (e:any)=>{
      assert.equal(e.code,'VALIDATION_ERROR');
      assert.ok(e.fieldErrors.some((x:any)=>x.field===field&&x.code===code));
      return true;
    }
  );
}

expectFieldError({title:''},'title','REQUIRED');
expectFieldError({title:'x'.repeat(501)},'title','TOO_LONG');
expectFieldError({description:'x'.repeat(10001)},'description','TOO_LONG');
expectFieldError({location:'x'.repeat(1001)},'location','TOO_LONG');
expectFieldError({isFixed:'yes'},'isFixed','INVALID_TYPE');
expectFieldError({startTime:'2026-10-05T12:00:00.000Z',endTime:'2026-10-05T11:00:00.000Z'},'startTime','INVALID_RANGE');
expectFieldError({startTime:'2026-10-05T12:00:00.000Z',endTime:'2026-10-05T11:00:00.000Z'},'endTime','INVALID_RANGE');
expectFieldError({startTime:'2026-10-05T00:00:00.000Z',endTime:'2026-10-06T01:00:00.000Z'},'startTime','TOO_LONG_RANGE');

const normalized=validateMergeOverrides({title:'  Updated  '},base);
assert.equal(normalized.title,'Updated');
assert.equal(normalized.startTime,base.startTime);
assert.equal(normalized.endTime,base.endTime);
assert.equal(snapshotsEqual({title:'A',startTime:base.startTime,endTime:base.endTime},{title:'A',startTime:base.startTime,endTime:base.endTime}),true);
assert.equal(snapshotsEqual({title:'A',startTime:base.startTime,endTime:base.endTime},{title:'B',startTime:base.startTime,endTime:base.endTime}),false);

console.log('manual conflict validation tests passed');
