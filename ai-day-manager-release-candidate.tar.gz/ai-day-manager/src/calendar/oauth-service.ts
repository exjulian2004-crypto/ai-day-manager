import { randomBytes } from 'node:crypto';
import { prisma } from '../persistence/prisma.js';
import { CalendarConnectionRepository } from '../persistence/calendar-connection-repository.js';
import { hashOAuthState } from '../persistence/token-vault.js';
import type { CalendarProviderType } from '@prisma/client';
const repo=new CalendarConnectionRepository(prisma);
const base=process.env.PUBLIC_BASE_URL??'http://localhost:3000';
type Provider='GOOGLE'|'MICROSOFT';
function cfg(p:Provider){
  if(p==='GOOGLE')return {
    auth:'https://accounts.google.com/o/oauth2/v2/auth',token:'https://oauth2.googleapis.com/token',
    id:process.env.GOOGLE_CLIENT_ID,secret:process.env.GOOGLE_CLIENT_SECRET,
    redirect:`${base}/api/calendar/google/callback`,
    scopes:['openid','email','https://www.googleapis.com/auth/calendar']
  };
  const tenant=process.env.MS_TENANT_ID??'common';
  return {
    auth:`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/authorize`,
    token:`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`,
    id:process.env.MS_CLIENT_ID,secret:process.env.MS_CLIENT_SECRET,
    redirect:`${base}/api/calendar/microsoft/callback`,
    scopes:['openid','profile','email','offline_access','Calendars.ReadWrite']
  };
}
export async function beginOAuth(userId:string,p:Provider){
  const c=cfg(p); if(!c.id||!c.secret)throw new Error(`${p} OAuth is not configured`);
  const state=randomBytes(32).toString('base64url');
  await prisma.oAuthState.create({data:{userId,provider:p as CalendarProviderType,stateHash:hashOAuthState(state),expiresAt:new Date(Date.now()+10*60_000)}});
  const u=new URL(c.auth);
  u.searchParams.set('client_id',c.id);u.searchParams.set('redirect_uri',c.redirect);u.searchParams.set('response_type','code');
  u.searchParams.set('scope',c.scopes.join(' '));u.searchParams.set('state',state);
  if(p==='GOOGLE'){u.searchParams.set('access_type','offline');u.searchParams.set('prompt','consent');u.searchParams.set('include_granted_scopes','true');}
  else u.searchParams.set('response_mode','query');
  return u.toString();
}
export async function finishOAuth(p:Provider,state:string,code:string){
  const c=cfg(p);
  const st=await prisma.oAuthState.findUnique({where:{stateHash:hashOAuthState(state)}});
  if(!st||st.expiresAt<=new Date()||st.provider!==p)throw new Error('Invalid or expired OAuth state');
  await prisma.oAuthState.delete({where:{id:st.id}});
  const body=new URLSearchParams({client_id:c.id!,client_secret:c.secret!,code,redirect_uri:c.redirect,grant_type:'authorization_code'});
  const r=await fetch(c.token,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body});
  if(!r.ok)throw new Error(`OAuth token exchange failed (${r.status})`);
  const t=await r.json() as any;if(!t.access_token)throw new Error('Provider returned no access token');
  let email:string|undefined,accountId:string|undefined;
  if(p==='GOOGLE'){
    const x=await fetch('https://www.googleapis.com/oauth2/v3/userinfo',{headers:{authorization:`Bearer ${t.access_token}`}});
    if(x.ok){const d=await x.json() as any;email=d.email;accountId=d.sub;}
  }else{
    const x=await fetch('https://graph.microsoft.com/v1.0/me?$select=id,mail,userPrincipalName',{headers:{authorization:`Bearer ${t.access_token}`}});
    if(x.ok){const d=await x.json() as any;email=d.mail??d.userPrincipalName;accountId=d.id;}
  }
  const old=await repo.get(st.userId,p);
  const refresh=t.refresh_token??old?.refreshToken;
  if(!refresh)throw new Error('No refresh token returned; reconnect the calendar');
  return repo.save({userId:st.userId,provider:p,providerAccountId:accountId,email,accessToken:t.access_token,refreshToken:refresh,
    expiresAt:new Date(Date.now()+Number(t.expires_in??3600)*1000),scope:t.scope});
}
