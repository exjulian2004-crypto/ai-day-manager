import { prisma } from '../persistence/prisma.js';
import { CalendarConnectionRepository } from '../persistence/calendar-connection-repository.js';
import type { CalendarEvent } from '../domain/types.js';
const repo=new CalendarConnectionRepository(prisma);
type Provider='GOOGLE'|'MICROSOFT';

async function connectionToken(userId:string,p:Provider){
  const c=await repo.get(userId,p);if(!c)throw new Error(`${p} calendar not connected`);
  if(c.accessToken&&c.expiresAt&&c.expiresAt.getTime()>Date.now()+60_000)return {token:c.accessToken,c};
  const tokenUrl=p==='GOOGLE'?'https://oauth2.googleapis.com/token':`https://login.microsoftonline.com/${process.env.MS_TENANT_ID??'common'}/oauth2/v2.0/token`;
  const body=new URLSearchParams({client_id:p==='GOOGLE'?process.env.GOOGLE_CLIENT_ID!:process.env.MS_CLIENT_ID!,
    client_secret:p==='GOOGLE'?process.env.GOOGLE_CLIENT_SECRET!:process.env.MS_CLIENT_SECRET!,
    refresh_token:c.refreshToken,grant_type:'refresh_token'});
  const r=await fetch(tokenUrl,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body});
  if(!r.ok)throw new Error(`${p} token refresh failed (${r.status})`);
  const t=await r.json() as any;
  await repo.updateTokens(c.id,{accessToken:t.access_token,refreshToken:t.refresh_token,expiresAt:new Date(Date.now()+Number(t.expires_in??3600)*1000)});
  return {token:t.access_token as string,c};
}

function commonEventFields(userId:string,id:string,x:any,start:string,end:string,source:string):CalendarEvent{
  return {id,userId,title:x.title??x.summary??x.subject??'(Ohne Titel)',description:x.description??x.bodyPreview,
    startTime:start,endTime:end,location:x.location??x.location?.displayName,priority:'P3',isFixed:true,source,
    preparationMinutes:0,travelMinutes:0,createdAt:x.createdAt??x.createdDateTime??new Date().toISOString(),
    updatedAt:x.updatedAt??x.lastModifiedDateTime??x.updated??new Date().toISOString()};
}

export async function getGoogleEvents(userId:string,start:Date,end:Date){
  const {token,c}=await connectionToken(userId,'GOOGLE');
  const u=new URL(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(c.calendarId??'primary')}/events`);
  u.searchParams.set('timeMin',start.toISOString());u.searchParams.set('timeMax',end.toISOString());
  u.searchParams.set('singleEvents','true');u.searchParams.set('orderBy','startTime');u.searchParams.set('showDeleted','true');
  const r=await fetch(u,{headers:{authorization:`Bearer ${token}`}});if(!r.ok)throw new Error(`Google Calendar read failed (${r.status})`);
  const d=await r.json() as any;
  return (d.items??[]).filter((e:any)=>e.status!=='cancelled'&&e.start?.dateTime&&e.end?.dateTime).map((e:any)=>commonEventFields(userId,`google:${e.id}`,e,e.start.dateTime,e.end.dateTime,'google'));
}
export async function getMicrosoftEvents(userId:string,start:Date,end:Date){
  const {token}=await connectionToken(userId,'MICROSOFT');
  const u=new URL('https://graph.microsoft.com/v1.0/me/calendarView');
  u.searchParams.set('startDateTime',start.toISOString());u.searchParams.set('endDateTime',end.toISOString());
  u.searchParams.set('$orderby','start/dateTime');u.searchParams.set('$top','1000');
  const r=await fetch(u,{headers:{authorization:`Bearer ${token}`,'Prefer':'outlook.timezone="UTC"'}});if(!r.ok)throw new Error(`Microsoft Calendar read failed (${r.status})`);
  const d=await r.json() as any;
  return (d.value??[]).filter((e:any)=>!e.isCancelled).map((e:any)=>commonEventFields(userId,`microsoft:${e.id}`,e,new Date(e.start.dateTime+'Z').toISOString(),new Date(e.end.dateTime+'Z').toISOString(),'microsoft'));
}

function googleBody(event:CalendarEvent){return {summary:event.title,description:event.description,location:event.location,start:{dateTime:event.startTime},end:{dateTime:event.endTime}};}
function microsoftBody(event:CalendarEvent){return {subject:event.title,body:{contentType:'text',content:event.description??''},start:{dateTime:event.startTime,timeZone:'UTC'},end:{dateTime:event.endTime,timeZone:'UTC'},location:event.location?{displayName:event.location}:undefined};}

export async function createGoogleEvent(userId:string,event:CalendarEvent){
  const {token,c}=await connectionToken(userId,'GOOGLE');
  const r=await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(c.calendarId??'primary')}/events`,{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body:JSON.stringify(googleBody(event))});
  if(!r.ok)throw new Error(`Google Calendar create failed (${r.status})`);
  const e=await r.json() as any; return `google:${e.id}`;
}
export async function updateGoogleEvent(userId:string,externalId:string,event:CalendarEvent){
  const {token,c}=await connectionToken(userId,'GOOGLE'); const id=externalId.replace(/^google:/,'');
  const r=await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(c.calendarId??'primary')}/events/${encodeURIComponent(id)}`,{method:'PATCH',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body:JSON.stringify(googleBody(event))});
  if(!r.ok)throw new Error(`Google Calendar update failed (${r.status})`);
}
export async function deleteGoogleEvent(userId:string,externalId:string){
  const {token,c}=await connectionToken(userId,'GOOGLE'); const id=externalId.replace(/^google:/,'');
  const r=await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(c.calendarId??'primary')}/events/${encodeURIComponent(id)}`,{method:'DELETE',headers:{authorization:`Bearer ${token}`}});
  if(!r.ok&&r.status!==404)throw new Error(`Google Calendar delete failed (${r.status})`);
}
export async function createMicrosoftEvent(userId:string,event:CalendarEvent){
  const {token}=await connectionToken(userId,'MICROSOFT');
  const r=await fetch('https://graph.microsoft.com/v1.0/me/events',{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body:JSON.stringify(microsoftBody(event))});
  if(!r.ok)throw new Error(`Microsoft Calendar create failed (${r.status})`);
  const e=await r.json() as any; return `microsoft:${e.id}`;
}
export async function updateMicrosoftEvent(userId:string,externalId:string,event:CalendarEvent){
  const {token}=await connectionToken(userId,'MICROSOFT'); const id=externalId.replace(/^microsoft:/,'');
  const r=await fetch(`https://graph.microsoft.com/v1.0/me/events/${encodeURIComponent(id)}`,{method:'PATCH',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body:JSON.stringify(microsoftBody(event))});
  if(!r.ok)throw new Error(`Microsoft Calendar update failed (${r.status})`);
}
export async function deleteMicrosoftEvent(userId:string,externalId:string){
  const {token}=await connectionToken(userId,'MICROSOFT'); const id=externalId.replace(/^microsoft:/,'');
  const r=await fetch(`https://graph.microsoft.com/v1.0/me/events/${encodeURIComponent(id)}`,{method:'DELETE',headers:{authorization:`Bearer ${token}`}});
  if(!r.ok&&r.status!==404)throw new Error(`Microsoft Calendar delete failed (${r.status})`);
}
