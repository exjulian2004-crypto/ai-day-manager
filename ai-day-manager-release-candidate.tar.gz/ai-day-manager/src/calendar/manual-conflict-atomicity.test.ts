import { strict as assert } from 'node:assert';
import { readFileSync } from 'node:fs';

const source=readFileSync(new URL('./manual-conflict-service.ts',import.meta.url),'utf8');
const branch=source.indexOf("if(choice==='LOCAL_WINS')");
assert.ok(branch>=0,'resolution branch missing');

const merged=source.indexOf("const candidate=mergeValues(local,external);",branch);
const validate=source.indexOf("validateMergeOverrides(overrides,candidate)",merged);
const localUpdate=source.indexOf("this.events.update(local.id,userId,final)",validate);
const providerGoogle=source.indexOf("updateGoogleEvent(userId,c.externalEventId,final)",validate);
const providerMicrosoft=source.indexOf("updateMicrosoftEvent(userId,c.externalEventId,final)",validate);

assert.ok(merged>=0,'merged candidate must be constructed');
assert.ok(validate>merged,'candidate must be validated before persistence');
assert.ok(localUpdate<0 || localUpdate>validate,'local mutation must follow validation');
assert.ok(providerGoogle<0 || providerGoogle>validate,'Google write must follow validation');
assert.ok(providerMicrosoft<0 || providerMicrosoft>validate,'Microsoft write must follow validation');

console.log('merge atomicity ordering test passed');
