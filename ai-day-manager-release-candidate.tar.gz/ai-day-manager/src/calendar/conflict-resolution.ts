import type { CalendarProviderType, CalendarSyncConflictType, CalendarSyncResolution, PrismaClient } from '@prisma/client';

export type SyncSnapshot={
  title:string;
  description?:string|null;
  startTime:string;
  endTime:string;
  location?:string|null;
  isFixed?:boolean;
};

export function snapshot(e:any):SyncSnapshot{
  return {
    title:e.title??'',
    description:e.description??null,
    startTime:new Date(e.startTime).toISOString(),
    endTime:new Date(e.endTime).toISOString(),
    location:e.location??null,
    isFixed:e.isFixed??false
  };
}

export function equalSnapshot(a:any,b:any){
  return JSON.stringify(snapshot(a))===JSON.stringify(snapshot(b));
}

export class ConflictRepository{
  constructor(private readonly db:PrismaClient){}
  async record(x:any){return this.db.calendarSyncConflict.create({data:x});}
  async getForUser(userId:string,id:string){return this.db.calendarSyncConflict.findFirst({where:{id,userId}});}
  async resolve(id:string,resolution:CalendarSyncResolution,reason:string){
    return this.db.calendarSyncConflict.updateMany({
      where:{id,resolvedAt:null},
      data:{resolution,resolvedAt:new Date(),reason}
    });
  }
  async list(userId:string,limit=100){
    return this.db.calendarSyncConflict.findMany({where:{userId},orderBy:{detectedAt:'desc'},take:limit});
  }
}
