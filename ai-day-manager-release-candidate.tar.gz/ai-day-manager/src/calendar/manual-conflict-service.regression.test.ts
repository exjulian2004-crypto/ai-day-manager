import { strict as assert } from 'node:assert';
import { readFileSync } from 'node:fs';

const source=readFileSync(new URL('./manual-conflict-service.ts',import.meta.url),'utf8');
const merged=source.indexOf("const candidate=mergeValues(local,external);");
const validation=source.indexOf("validateMergeOverrides(overrides,candidate)",merged);
const localWrite=source.indexOf("this.events.update(local.id,userId,final)",merged);
assert.ok(merged>=0,'merged branch must exist');
assert.ok(validation>merged,'merged branch must validate candidate');
assert.ok(localWrite>validation,'local write must happen after validation');
console.log('merge validation ordering regression passed');
