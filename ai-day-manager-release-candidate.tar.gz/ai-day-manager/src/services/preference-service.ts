import type { UserPreferences } from '../domain/types.js';
import { PrismaPreferencesRepository } from '../persistence/preferences-repository.js';

export class PreferenceService {
  constructor(private readonly repo:PrismaPreferencesRepository){}
  get(userId:string){return this.repo.get(userId);}
  set(userId:string,p:UserPreferences){return this.repo.set(userId,p);}
}
