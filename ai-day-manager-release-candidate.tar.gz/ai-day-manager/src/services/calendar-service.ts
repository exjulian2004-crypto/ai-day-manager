import type { CalendarEvent } from '../domain/types.js';
import { PrismaEventRepository } from '../persistence/event-repository.js';

export interface CalendarProvider {
  getEvents(userId:string,start:Date,end:Date):Promise<CalendarEvent[]>;
  createEvent(event:CalendarEvent):Promise<CalendarEvent>;
  updateEvent(id:string,userId:string,patch:Partial<CalendarEvent>):Promise<CalendarEvent>;
  deleteEvent(id:string,userId:string):Promise<void>;
}
export class PrismaCalendarProvider implements CalendarProvider {
  constructor(private readonly repo:PrismaEventRepository){}
  getEvents(userId:string,start:Date,end:Date){return this.repo.getDay(userId,start,end);}
  createEvent(event:CalendarEvent){return this.repo.create(event);}
  updateEvent(id:string,userId:string,patch:Partial<CalendarEvent>){return this.repo.update(id,userId,patch);}
  deleteEvent(id:string,userId:string){return this.repo.delete(id,userId);}
}
export class CalendarService {
  constructor(private readonly provider:CalendarProvider){}
  getDay(userId:string,start:Date,end:Date){return this.provider.getEvents(userId,start,end);}
  create(event:CalendarEvent){return this.provider.createEvent(event);}
  update(id:string,userId:string,patch:Partial<CalendarEvent>){return this.provider.updateEvent(id,userId,patch);}
  delete(id:string,userId:string){return this.provider.deleteEvent(id,userId);}
}
