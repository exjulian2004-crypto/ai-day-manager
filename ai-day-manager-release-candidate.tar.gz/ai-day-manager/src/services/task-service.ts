import type { Priority, SchedulingMode, Task } from '../domain/types.js';
import { PrismaTaskRepository } from '../persistence/task-repository.js';

export interface CreateTaskInput {
  userId:string; title:string; description?:string; priority?:Priority;
  estimatedDurationMinutes?:number; deadline?:string; schedulingMode?:SchedulingMode;
  preferredStart?:string; preferredEnd?:string;
}
export class TaskService {
  constructor(private readonly repo:PrismaTaskRepository){}
  async create(input:CreateTaskInput):Promise<Task>{
    if(!input.title.trim()) throw new Error('Task title is required');
    return this.repo.create({
      userId:input.userId,title:input.title.trim(),description:input.description,
      priority:input.priority??'P3',estimatedDurationMinutes:input.estimatedDurationMinutes??30,
      deadline:input.deadline,schedulingMode:input.schedulingMode??'FLEXIBLE',
      preferredStart:input.preferredStart,preferredEnd:input.preferredEnd,status:'OPEN'
    });
  }
  list(userId:string){return this.repo.list(userId);}
  get(id:string,userId:string){return this.repo.get(id,userId);}
  update(id:string,userId:string,patch:Partial<Task>){return this.repo.update(id,userId,patch);}
}
