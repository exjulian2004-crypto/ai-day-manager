import type { StructuredModel } from './ai-service.js';

const INTENT_SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    intent: { type:"string", enum:["create_task","create_event","update_task","move_task","recalculate_day","unknown"] },
    entities: { type:"object", additionalProperties:true },
    missing_information: { type:"array", items:{type:"string"} },
    confidence: { type:"number", minimum:0, maximum:1 },
    assumptions: { type:"array", items:{type:"string"} }
  },
  required:["intent","entities","missing_information","confidence","assumptions"]
};

export class OpenAIResponsesModel implements StructuredModel {
  constructor(
    private readonly apiKey=process.env.OPENAI_API_KEY,
    private readonly model=process.env.OPENAI_MODEL ?? "gpt-6-luna"
  ) {}

  async parse(input:string, context?:unknown):Promise<unknown> {
    if(!this.apiKey) throw new Error("OPENAI_API_KEY is not configured");
    const response=await fetch("https://api.openai.com/v1/responses",{
      method:"POST",
      headers:{
        "authorization":`Bearer ${this.apiKey}`,
        "content-type":"application/json"
      },
      body:JSON.stringify({
        model:this.model,
        input:[
          {role:"system",content:[{type:"input_text",text:
            `Du bist der AI Understanding Layer des AI Day Managers.
Nur strukturierte Intent-Daten erzeugen. Niemals Kalenderplanung selbst durchführen.
Datumskontext: ${JSON.stringify(context ?? {})}`}]},
          {role:"user",content:[{type:"input_text",text:input}]}
        ],
        text:{
          format:{
            type:"json_schema",
            name:"day_manager_intent",
            strict:true,
            schema:INTENT_SCHEMA
          }
        }
      })
    });
    if(!response.ok) throw new Error(`OpenAI API error ${response.status}`);
    const data=await response.json() as {output_text?:string};
    if(!data.output_text) throw new Error("OpenAI returned no structured output");
    return JSON.parse(data.output_text);
  }
}
