import type { Priority, SchedulingMode } from '../domain/types.js';

export type IntentName =
  | 'create_task' | 'create_event' | 'update_task' | 'move_task'
  | 'recalculate_day' | 'unknown';

export type Intent = {
  intent: IntentName;
  entities: Record<string, unknown>;
  missing_information: string[];
  confidence: number;
  assumptions: string[];
};

const priorities = new Set<Priority>(['P1','P2','P3','P4','P5']);
const modes = new Set<SchedulingMode>(['FIXED','FLEXIBLE','DEADLINE','PREFERRED_WINDOW','ANYTIME']);

export function intentSchema(value: unknown): Intent {
  if (!value || typeof value !== 'object') throw new Error('Invalid AI intent');
  const x = value as Record<string, unknown>;
  if (!['create_task','create_event','update_task','move_task','recalculate_day','unknown'].includes(String(x.intent))) {
    throw new Error('Invalid AI intent name');
  }
  if (!x.entities || typeof x.entities !== 'object' || Array.isArray(x.entities)) throw new Error('Invalid AI entities');
  if (!Array.isArray(x.missing_information) || x.missing_information.some(v => typeof v !== 'string')) throw new Error('Invalid missing_information');
  if (!Array.isArray(x.assumptions) || x.assumptions.some(v => typeof v !== 'string')) throw new Error('Invalid assumptions');
  if (typeof x.confidence !== 'number' || x.confidence < 0 || x.confidence > 1) throw new Error('Invalid AI confidence');

  const e = x.entities as Record<string, unknown>;
  if (e.priority !== undefined && !priorities.has(e.priority as Priority)) throw new Error('Invalid priority');
  if (e.scheduling_mode !== undefined && !modes.has(e.scheduling_mode as SchedulingMode)) throw new Error('Invalid scheduling mode');
  if (e.duration_minutes !== undefined && (!Number.isInteger(e.duration_minutes) || Number(e.duration_minutes) <= 0)) {
    throw new Error('Invalid duration');
  }
  return {
    intent: x.intent as IntentName,
    entities: e,
    missing_information: x.missing_information as string[],
    confidence: x.confidence as number,
    assumptions: x.assumptions as string[],
  };
}

export type TaskIntentEntities = {
  title: string; description?: string; duration_minutes?: number; priority?: Priority;
  scheduling_mode?: SchedulingMode; deadline?: string; preferred_start?: string; preferred_end?: string;
};
