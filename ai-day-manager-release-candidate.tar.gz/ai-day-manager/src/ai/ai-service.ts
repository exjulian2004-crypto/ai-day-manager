import type { Intent } from './intent.js';
import type { Priority } from '../domain/types.js';
import { intentSchema } from './intent.js';

export interface StructuredModel {
  parse(input: string, context?: unknown): Promise<unknown>;
}

/** Side-effect-free AI boundary. It may interpret, but never mutate application state. */
export class AIService {
  constructor(private readonly model: StructuredModel) {}

  async parse(input: string, context?: unknown): Promise<Intent> {
    const raw = await this.model.parse(input, context);
    try {
      return intentSchema(raw);
    } catch {
      const repaired = await this.model.parse(
        `Return ONLY a valid JSON intent matching the application schema. Repair this invalid result: ${JSON.stringify(raw)}`,
        context,
      );
      return intentSchema(repaired);
    }
  }
}

/**
 * Deterministic MVP model. Replace with an LLM adapter without changing the
 * application or planning layers.
 */
export class RuleBasedStructuredModel implements StructuredModel {
  async parse(input: string, context?: unknown): Promise<unknown> {
    const text = input.trim();
    const lower = text.toLowerCase();

    if (/neu\s+berechnen|neu\s+planen|recalculate|replan/.test(lower)) {
      return { intent:'recalculate_day', entities:{}, missing_information:[], confidence:0.99, assumptions:[] };
    }

    const date = resolveDate(lower, context);
    const time = matchTime(lower);
    const duration = matchDuration(lower);
    const priority = inferPriority(lower);
    const title = cleanTitle(text);

    if (time) {
      return {
        intent:'create_event',
        entities:{
          title, date, start_time:time, duration_minutes:duration ?? 60,
          priority:priority ?? 'P3',
          preparation_minutes:/bewerbung|interview|arzt|zahnarzt|werkstatt|termin/.test(lower) ? 30 : 0,
        },
        missing_information:[],
        confidence:0.86,
        assumptions:[duration ? 'Dauer aus Eingabe erkannt' : 'Dauer standardmäßig auf 60 Minuten gesetzt'],
      };
    }

    return {
      intent:'create_task',
      entities:{
        title:title || text,
        deadline:/heute|today/.test(lower) ? date : undefined,
        duration_minutes:duration ?? 30,
        priority:priority ?? 'P3',
        scheduling_mode:/deadline|bis\s+(heute|morgen|freitag|montag|dienstag|mittwoch|donnerstag|samstag|sonntag)/.test(lower) ? 'DEADLINE' : 'FLEXIBLE',
      },
      missing_information:[],
      confidence:0.78,
      assumptions:[duration ? 'Dauer aus Eingabe erkannt' : 'Dauer auf 30 Minuten geschätzt'],
    };
  }
}
function resolveDate(text:string, context:any):string {
  const base = context?.date ? new Date(`${context.date}T12:00:00`) : new Date();
  if (/morgen|tomorrow/.test(text)) base.setDate(base.getDate()+1);
  return base.toISOString().slice(0,10);
}
function matchTime(text:string):string|undefined {
  const m=text.match(/(?:um|at)\s+(\d{1,2})(?::(\d{2}))?\b/) || text.match(/\b(\d{1,2}):(\d{2})\b/);
  return m ? `${String(Number(m[1])).padStart(2,'0')}:${m[2] ?? '00'}` : undefined;
}
function matchDuration(text:string):number|undefined {
  const h=text.match(/(\d+(?:[.,]\d+)?)\s*(?:stunden?|std\.?)/);
  const m=text.match(/(\d+)\s*(?:minuten?|min\.?)/);
  if(h) return Math.round(Number(h[1].replace(',','.'))*60);
  if(m) return Number(m[1]);
  return undefined;
}
function inferPriority(text:string):Priority|undefined {
  if(/arzt|zahnarzt|bewerbungsgespräch|interview|muss\s+heute|harte\s+deadline/.test(text)) return 'P1';
  if(/wichtig|dringend|kunden|bewerbung/.test(text)) return 'P2';
  return undefined;
}
function cleanTitle(text:string):string {
  return text.replace(/^(ich\s+(muss|möchte|will)|plane\s+mir|bitte\s+)/i,'').trim().replace(/[.!?]+$/,'');
}
