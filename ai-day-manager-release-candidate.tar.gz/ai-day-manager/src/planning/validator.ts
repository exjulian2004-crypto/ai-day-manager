import {DailyPlan,PlanBlock,PlanningConflict} from '../domain/types.js';
import {minutes} from './time.js';
export function validatePlan(plan:DailyPlan):string[]{ const errors:string[]=[]; const sorted=[...plan.blocks].sort((a,b)=>minutes(a.startTime)-minutes(b.startTime)); for(const b of sorted){if(minutes(b.endTime)<=minutes(b.startTime)) errors.push(`Invalid duration: ${b.title}`);} for(let i=1;i<sorted.length;i++){if(minutes(sorted[i].startTime)<minutes(sorted[i-1].endTime)) errors.push(`Overlap: ${sorted[i-1].title} / ${sorted[i].title}`);} return errors; }
