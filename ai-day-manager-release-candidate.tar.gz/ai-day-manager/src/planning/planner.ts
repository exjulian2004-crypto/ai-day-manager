import {DailyPlan,PlanBlock,PlanningConflict,PlanningInput,Task,CalendarEvent,Priority} from '../domain/types.js';
import {minutes,hhmm} from './time.js';
const pScore:Record<Priority,number>={P1:100,P2:80,P3:60,P4:40,P5:20};
const id=(prefix:string,n:number)=>`${prefix}-${n}`;
export class PlanningEngine {
  generate(input:PlanningInput):DailyPlan {
    const {date,preferences}=input; const conflicts:PlanningConflict[]=[]; const blocks:PlanBlock[]=[];
    const fixed=input.calendarEvents.filter(e=>e.isFixed && e.startTime.startsWith(date));
    const occupied:PlanBlock[]=[];
    for(const e of fixed){ const s=minutes(e.startTime.slice(11,16)), end=minutes(e.endTime.slice(11,16)); const b:PlanBlock={id:id('event',blocks.length),userId:input.userId,date,type:'FIXED_EVENT',title:e.title,startTime:hhmm(s),endTime:hhmm(end),source:e.source,priority:e.priority,locked:true,eventId:e.id,reason:'Fixed calendar event'}; blocks.push(b);occupied.push(b); }
    // Detect fixed-vs-fixed collisions before scheduling anything else.
    for(let i=0;i<occupied.length;i++) for(let j=i+1;j<occupied.length;j++) if(minutes(occupied[i].startTime)<minutes(occupied[j].endTime)&&minutes(occupied[j].startTime)<minutes(occupied[i].endTime)) conflicts.push({id:id('conflict',conflicts.length),userId:input.userId,date,type:'FIXED_EVENT_COLLISION',severity:'CRITICAL',description:`${occupied[i].title} kollidiert mit ${occupied[j].title}.`,relatedBlocks:[occupied[i].id,occupied[j].id],resolutionStatus:'OPEN'});
    const workStart=minutes(preferences.workStartTime), workEnd=minutes(preferences.workEndTime);
    const freeSlots=()=>{const sorted=[...blocks].sort((a,b)=>minutes(a.startTime)-minutes(b.startTime)); const slots:{start:number,end:number}[]=[]; let cursor=workStart; for(const b of sorted){const s=minutes(b.startTime),e=minutes(b.endTime); if(s>cursor) slots.push({start:cursor,end:s}); cursor=Math.max(cursor,e);} if(cursor<workEnd) slots.push({start:cursor,end:workEnd}); return slots;};
    const tasks=input.tasks.filter(t=>t.status!=='DONE'&&t.status!=='CANCELLED').sort((a,b)=>{const aToday=a.deadline?.startsWith(date)?1:0, bToday=b.deadline?.startsWith(date)?1:0; if(aToday!==bToday) return bToday-aToday; const da=a.deadline?new Date(a.deadline).getTime():Infinity, db=b.deadline?new Date(b.deadline).getTime():Infinity; return pScore[b.priority]-pScore[a.priority] || da-db;});
    for(const task of tasks){ const dur=task.estimatedDurationMinutes; let best:{start:number,end:number,score:number}|null=null; for(const slot of freeSlots()){for(let s=slot.start;s+dur<=slot.end;s+=15){let score=pScore[task.priority]; if(task.deadline && task.deadline.startsWith(date)) score+=60; const preferred=task.preferredStart&&task.preferredEnd; if(preferred && s>=minutes(task.preferredStart!)&&s+dur<=minutes(task.preferredEnd!)) score+=20; if(task.priority==='P1') score+=10; score-=Math.max(0,(slot.end-slot.start-dur))/60; if(!best||score>best.score) best={start:s,end:s+dur,score};}} if(best){ const b:PlanBlock={id:id('task',blocks.length),userId:input.userId,date,type:task.priority==='P1'||dur>=preferences.preferredDeepWorkDurationMinutes?'DEEP_WORK':'FLEXIBLE_TASK',title:task.title,startTime:hhmm(best.start),endTime:hhmm(best.end),source:'planning-engine',priority:task.priority,locked:false,taskId:task.id,reason:this.reason(task,best.start,preferences)}; blocks.push(b); } else conflicts.push({id:id('conflict',conflicts.length),userId:input.userId,date,type:'NO_CAPACITY',severity:task.priority==='P1'?'CRITICAL':'WARNING',description:`Für „${task.title}“ ist heute kein geeignetes Zeitfenster verfügbar.`,relatedBlocks:[],resolutionStatus:'OPEN'}); }
    const enriched=this.addBreaksAndBuffers(blocks,input); const quality=this.quality(enriched,conflicts); const plan={date,blocks:enriched.sort((a,b)=>minutes(a.startTime)-minutes(b.startTime)),conflicts,recommendations:[],qualityScore:quality}; return plan;
  }
  private reason(t:Task,start:number,p:any){const why=[] as string[]; why.push(`Priorität ${t.priority}`); if(t.deadline) why.push(t.deadline.startsWith('')?'Deadline berücksichtigt':''); why.push(`${hhmm(start)} liegt innerhalb deiner Arbeitszeit`); return why.filter(Boolean).join(' · ');}
  private addBreaksAndBuffers(blocks:PlanBlock[],input:PlanningInput){
    const sorted=[...blocks].sort((a,b)=>minutes(a.startTime)-minutes(b.startTime));
    const out:PlanBlock[]=[];
    for(const b of sorted){
      const duration=minutes(b.endTime)-minutes(b.startTime);
      if(duration >= 120 && (b.type==='DEEP_WORK'||b.type==='FLEXIBLE_TASK')) {
        const firstEnd=minutes(b.startTime)+60;
        const breakEnd=firstEnd+input.preferences.preferredBreakDurationMinutes;
        out.push({...b,id:`${b.id}-a`,endTime:hhmm(firstEnd),reason:`${b.reason??''} · Fokusblock aufgeteilt`});
        out.push({id:id('break',out.length),userId:input.userId,date:input.date,type:'BREAK',title:'Pause',startTime:hhmm(firstEnd),endTime:hhmm(breakEnd),source:'planning-engine',locked:false,reason:'Pause nach langem Fokusblock'});
        out.push({...b,id:`${b.id}-b`,startTime:hhmm(breakEnd),endTime:hhmm(breakEnd+(duration-60)),reason:`${b.reason??''} · Fortsetzung nach Pause`});
        continue;
      }
      if(out.length){
        const prev=out[out.length-1];
        const gap=minutes(b.startTime)-minutes(prev.endTime);
        if(gap>=input.preferences.defaultBufferMinutes*2 && prev.type!=='BREAK') out.push({id:id('buffer',out.length),userId:input.userId,date:input.date,type:'BUFFER',title:'Puffer',startTime:prev.endTime,endTime:hhmm(minutes(prev.endTime)+input.preferences.defaultBufferMinutes),source:'planning-engine',locked:false,reason:'Sicherheitsreserve'});
        else if(gap>=input.preferences.preferredBreakDurationMinutes && minutes(prev.endTime)-minutes(prev.startTime)>=60) out.push({id:id('break',out.length),userId:input.userId,date:input.date,type:'BREAK',title:'Pause',startTime:prev.endTime,endTime:hhmm(minutes(prev.endTime)+input.preferences.preferredBreakDurationMinutes),source:'planning-engine',locked:false,reason:'Pause nach Fokusblock'});
      }
      out.push(b);
    }
    return out;
  }
  private quality(blocks:PlanBlock[],conflicts:PlanningConflict[]){return Math.max(0,Math.min(100,100-conflicts.length*20-blocks.filter(b=>b.type==='BUFFER').length*2));}
}
