import { PlanningEngine } from '../planning/planner.js';
import type { CalendarEvent, Task, UserPreferences, DailyPlan } from '../domain/types.js';
export class DayService {
  private readonly engine=new PlanningEngine();
  generate(input:{date:string;userId:string;calendarEvents:CalendarEvent[];tasks:Task[];preferences:UserPreferences}):DailyPlan{
    return this.engine.generate(input);
  }
}
