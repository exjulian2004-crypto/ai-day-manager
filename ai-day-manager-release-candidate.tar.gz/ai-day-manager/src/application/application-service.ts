import type { CalendarEvent, DailyPlan, Task } from '../domain/types.js';
import type { Intent } from '../ai/intent.js';
import { AIService } from '../ai/ai-service.js';
import { TaskService } from '../services/task-service.js';
import { CalendarService } from '../services/calendar-service.js';
import { PreferenceService } from '../services/preference-service.js';
import { DayService } from './day-service.js';
import { PrismaPlanRepository } from '../persistence/plan-repository.js';
import { validatePlan } from '../planning/validator.js';

export type ActionResult = {
  intent: Intent; action:'CREATED_TASK'|'CREATED_EVENT'|'RECALCULATED'|'NEEDS_INPUT'|'REJECTED';
  task?:Task; event?:CalendarEvent; plan?:DailyPlan; message:string;
};

export class ApplicationService {
  constructor(
    private readonly ai:AIService, private readonly tasks:TaskService,
    private readonly calendar:CalendarService, private readonly preferences:PreferenceService,
    private readonly day:DayService, private readonly plans:PrismaPlanRepository,
  ) {}

  async handleNaturalLanguage(userId:string,input:string,date:string):Promise<ActionResult>{
    const intent=await this.ai.parse(input,{userId,date});
    if(intent.missing_information.length)return {intent,action:'NEEDS_INPUT',message:`Ich brauche noch: ${intent.missing_information.join(', ')}.`};
    switch(intent.intent){
      case 'create_task': return this.createTaskAndPlan(userId,intent,date);
      case 'create_event': return this.createEventAndPlan(userId,intent,date);
      case 'recalculate_day': return {intent,action:'RECALCULATED',plan:await this.recalculate(userId,date),message:'Der Tagesplan wurde neu berechnet.'};
      default:return {intent,action:'REJECTED',message:'Diese Aktion wird im MVP noch nicht unterstützt.'};
    }
  }

  async recalculate(userId:string,date:string):Promise<DailyPlan>{
    const prefs=await this.preferences.get(userId);
    const [events,tasks]=await Promise.all([
      this.calendar.getDay(userId,new Date(`${date}T00:00:00.000Z`),new Date(`${date}T23:59:59.999Z`)),
      this.tasks.list(userId)
    ]);
    const plan=this.day.generate({date,userId,calendarEvents:events,tasks,preferences:prefs});
    const errors=validatePlan(plan); if(errors.length)throw new Error(`Plan validation failed: ${errors.join('; ')}`);
    return this.plans.replaceDay(userId,date,plan);
  }

  async getPersistedPlan(userId:string,date:string){return this.plans.getDay(userId,date);}

  private async createTaskAndPlan(userId:string,intent:Intent,date:string):Promise<ActionResult>{
    const e=intent.entities;
    const task=await this.tasks.create({userId,title:String(e.title),description:e.description?String(e.description):undefined,
      priority:e.priority as any,estimatedDurationMinutes:e.duration_minutes as number|undefined,
      deadline:e.deadline?String(e.deadline):undefined,schedulingMode:e.scheduling_mode as any,
      preferredStart:e.preferred_start?String(e.preferred_start):undefined,preferredEnd:e.preferred_end?String(e.preferred_end):undefined});
    return {intent,action:'CREATED_TASK',task,plan:await this.recalculate(userId,date),message:`„${task.title}“ wurde hinzugefügt und eingeplant.`};
  }

  private async createEventAndPlan(userId:string,intent:Intent,date:string):Promise<ActionResult>{
    const e=intent.entities;if(!e.start_time)return {intent,action:'NEEDS_INPUT',message:'Um wie viel Uhr ist der Termin?'};
    const eventDate=String(e.date??date), startTime=`${eventDate}T${String(e.start_time)}:00.000Z`;
    const duration=Number(e.duration_minutes??60), endTime=new Date(new Date(startTime).getTime()+duration*60000).toISOString();
    const event:CalendarEvent={id:'',userId,title:String(e.title),startTime,endTime,location:e.location?String(e.location):undefined,
      priority:(e.priority as any)??'P3',isFixed:true,source:'ai',preparationMinutes:Number(e.preparation_minutes??0),
      travelMinutes:Number(e.travel_minutes??0),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
    const existing=await this.calendar.getDay(userId,new Date(startTime),new Date(endTime));
    const duplicate=existing.find(x=>x.title.trim().toLowerCase()===event.title.trim().toLowerCase()&&x.startTime===event.startTime);
    if(duplicate)return {intent,action:'REJECTED',message:`„${event.title}“ scheint bereits zu existieren. Ich habe keinen zweiten Termin angelegt.`};
    const overlap=existing.find(x=>x.startTime<event.endTime&&x.endTime>event.startTime);
    if(overlap&&overlap.priority==='P1'&&event.priority==='P1')return {intent,action:'REJECTED',message:`Konflikt: „${event.title}“ kollidiert mit „${overlap.title}“. Kritische Termine werden nicht automatisch verändert.`};
    const saved=await this.calendar.create(event);
    return {intent,action:'CREATED_EVENT',event:saved,plan:await this.recalculate(userId,eventDate),message:`„${saved.title}“ wurde als fester Termin angelegt und der Tag neu geplant.`};
  }
}
