import { AIService, RuleBasedStructuredModel } from '../ai/ai-service.js';
import { OpenAIResponsesModel } from '../ai/openai-model.js';
import { ApplicationService } from './application-service.js';
import { TaskService } from '../services/task-service.js';
import { CalendarService } from '../services/calendar-service.js';
import { SyncedCalendarProvider } from '../calendar/sync-provider.js';
import { PreferenceService } from '../services/preference-service.js';
import { PrismaTaskRepository } from '../persistence/task-repository.js';
import { PrismaEventRepository } from '../persistence/event-repository.js';
import { PrismaPreferencesRepository } from '../persistence/preferences-repository.js';
import { PrismaPlanRepository } from '../persistence/plan-repository.js';
import { prisma } from '../persistence/prisma.js';
import { DayService } from './day-service.js';

export function createApplication():ApplicationService{
  const model=process.env.OPENAI_API_KEY?new OpenAIResponsesModel():new RuleBasedStructuredModel();
  return new ApplicationService(
    new AIService(model),
    new TaskService(new PrismaTaskRepository(prisma)),
    new CalendarService(new SyncedCalendarProvider(new PrismaEventRepository(prisma))),
    new PreferenceService(new PrismaPreferencesRepository(prisma)),
    new DayService(),
    new PrismaPlanRepository(prisma)
  );
}
