import { createApplication } from './bootstrap.js';
export const app=createApplication();
