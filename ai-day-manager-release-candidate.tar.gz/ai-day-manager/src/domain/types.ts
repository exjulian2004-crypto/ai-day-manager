export type Priority = 'P1'|'P2'|'P3'|'P4'|'P5';
export type SchedulingMode = 'FIXED'|'FLEXIBLE'|'DEADLINE'|'PREFERRED_WINDOW'|'ANYTIME';
export type TaskStatus = 'OPEN'|'IN_PROGRESS'|'DONE'|'CANCELLED';
export type AutonomyLevel = 'SUPPORTED'|'AUTOMATIC'|'AUTONOMOUS';
export type BlockType = 'FIXED_EVENT'|'FLEXIBLE_TASK'|'PREPARATION'|'TRAVEL'|'BUFFER'|'BREAK'|'MEAL'|'PERSONAL'|'RECOVERY'|'DEEP_WORK'|'ADMIN'|'FREE_TIME';
export type ConflictSeverity = 'INFO'|'WARNING'|'CRITICAL';

export interface UserPreferences {
  workStartTime:string; workEndTime:string; sleepStartTime:string; sleepEndTime:string;
  preferredBreakDurationMinutes:number; preferredDeepWorkDurationMinutes:number;
  defaultBufferMinutes:number; autonomyLevel:AutonomyLevel; timezone:string;
  preferredExerciseWindow?:{start:string;end:string};
}
export interface Task { id:string; userId:string; title:string; description?:string; priority:Priority; estimatedDurationMinutes:number; deadline?:string; schedulingMode:SchedulingMode; status:TaskStatus; preferredStart?:string; preferredEnd?:string; createdAt:string; updatedAt:string; }
export interface CalendarEvent { id:string; userId:string; title:string; description?:string; startTime:string; endTime:string; location?:string; priority:Priority; isFixed:boolean; source:string; preparationMinutes?:number; travelMinutes?:number; createdAt:string; updatedAt:string; }
export interface PlanBlock { id:string; userId:string; date:string; type:BlockType; title:string; startTime:string; endTime:string; source:string; priority?:Priority; locked:boolean; reason?:string; taskId?:string; eventId?:string; }
export interface PlanningConflict { id:string; userId:string; date:string; type:string; severity:ConflictSeverity; description:string; relatedBlocks:string[]; resolutionStatus:'OPEN'|'RESOLVED'|'IGNORED'; }
export interface PlanningRecommendation { type:string; title:string; description:string; taskId?:string; }
export interface PlanningInput { date:string; now?:string; userId:string; calendarEvents:CalendarEvent[]; tasks:Task[]; preferences:UserPreferences; existingBlocks?:PlanBlock[]; }
export interface DailyPlan { date:string; blocks:PlanBlock[]; conflicts:PlanningConflict[]; recommendations:PlanningRecommendation[]; qualityScore:number; }
