import http from 'node:http';
import { URL } from 'node:url';
import { app } from './application/app-store.js';
import { auth, currentUser, setSession, clearSession, requireUser } from './auth/http-auth.js';
import { beginOAuth, finishOAuth } from './calendar/oauth-service.js';
import { CalendarConnectionRepository } from './persistence/calendar-connection-repository.js';
import { prisma } from './persistence/prisma.js';

const PORT=Number(process.env.PORT??3000);


const html=String.raw`<!doctype html>
<html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Day Manager</title>
<style>
:root{font-family:Inter,system-ui,sans-serif;color:#18202a;background:#f6f7f9;--card:#fff;--muted:#687386;--accent:#315efb}
*{box-sizing:border-box}body{margin:0}.app{display:flex;min-height:100vh}.nav{width:230px;background:#111827;color:#e5e7eb;padding:24px 14px;position:fixed;height:100vh}.brand{font-size:20px;font-weight:750;padding:0 10px 28px}.nav button{display:block;width:100%;border:0;background:transparent;color:#aeb7c6;text-align:left;padding:12px 10px;border-radius:9px;margin:4px 0;cursor:pointer}.nav button.active,.nav button:hover{background:#1f2937;color:#fff}.main{margin-left:230px;width:calc(100% - 230px);padding:32px;max-width:1250px}.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}.muted{color:var(--muted)}.grid{display:grid;grid-template-columns:2fr 1fr;gap:18px}.card{background:var(--card);border:1px solid #e7e9ee;border-radius:16px;padding:20px;box-shadow:0 2px 8px #00000006}.plan{display:flex;gap:15px;padding:15px 0;border-bottom:1px solid #edf0f4}.time{width:110px;color:var(--muted);font-variant-numeric:tabular-nums}.pill{font-size:12px;padding:4px 8px;border-radius:999px;background:#eef2ff;color:#294bd1}.composer{display:flex;gap:10px;margin-top:15px}.composer input{flex:1;padding:13px;border:1px solid #d9dde5;border-radius:10px}.primary{background:var(--accent);color:white;border:0;border-radius:10px;padding:12px 17px;cursor:pointer}.item{padding:14px 0;border-bottom:1px solid #edf0f4}.empty{padding:35px;text-align:center;color:var(--muted)}label{display:block;margin:15px 0 6px;font-size:13px;font-weight:600}select,input[type=time],input[type=text]{padding:10px;border:1px solid #d9dde5;border-radius:9px}h1{margin:0;font-size:28px}h2{font-size:18px}.notice{background:#fff7ed;border:1px solid #fed7aa;padding:12px;border-radius:10px}.success{background:#ecfdf5;border:1px solid #a7f3d0;padding:12px;border-radius:10px}
@media(max-width:760px){.nav{width:72px;padding:15px 8px}.brand{font-size:0}.brand:after{content:'AI';font-size:18px}.nav button{font-size:0;text-align:center}.nav button:before{content:'•';font-size:20px}.main{margin-left:72px;width:calc(100% - 72px);padding:18px}.grid{grid-template-columns:1fr}.time{width:80px}}
.auth{max-width:420px;margin:10vh auto}.auth input{width:100%;padding:12px;margin:6px 0 12px;border:1px solid #d9dde5;border-radius:9px}.error{background:#fef2f2;border:1px solid #fecaca;padding:10px;border-radius:9px;margin:10px 0}
.conflict-panel{margin-top:18px}
.conflict-filters{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:12px 0}
.conflict-filters select,.conflict-filters input{border:1px solid var(--border,#ddd);border-radius:10px;padding:9px;background:var(--surface,#fff);color:inherit}
.conflict-summary{display:flex;gap:18px;padding:8px 0 12px;font-size:13px;opacity:.72}
.conflict-list{display:grid;gap:8px}
.conflict-card{display:block;text-align:left;width:100%;padding:13px;border:1px solid var(--border,#ddd);border-radius:12px;background:var(--surface,#fff);cursor:pointer;color:inherit}
.conflict-card:hover{border-color:#888;transform:translateY(-1px)}
.conflict-card-top,.conflict-meta{display:flex;justify-content:space-between;align-items:center;gap:8px}
.provider-badge,.status-badge{font-size:11px;font-weight:700;padding:3px 7px;border-radius:999px}
.provider-badge.google{background:#f1f4ff}.provider-badge.microsoft{background:#edf8f1}
.status-badge.open{background:#fff2d9}.status-badge.resolved{background:#eaf7ed}
.conflict-title{font-weight:700;margin:9px 0 4px}.conflict-reason{font-size:13px;opacity:.72;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.conflict-meta{font-size:12px;opacity:.62;margin-top:9px}
.empty-state{padding:24px;text-align:center;opacity:.6}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.42);display:flex;align-items:center;justify-content:center;padding:20px;z-index:20}
.modal.hidden{display:none}.modal-card{max-width:1000px;width:100%;max-height:90vh;overflow:auto;background:var(--surface,#fff);border-radius:18px;padding:22px;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.modal-head{display:flex;justify-content:space-between;align-items:flex-start}.modal-head button{border:0;background:transparent;font-size:28px;cursor:pointer}
.eyebrow,.snapshot-title{font-size:11px;text-transform:uppercase;letter-spacing:.08em;opacity:.55;font-weight:700}
.detail-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:18px 0}
.detail-grid div{padding:11px;border:1px solid var(--border,#ddd);border-radius:10px}.detail-grid span{display:block;font-size:11px;opacity:.55;margin-bottom:4px}
.reason-box{padding:12px;border-radius:10px;background:rgba(127,127,127,.08);margin-bottom:16px}
.snapshot-columns{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.snapshot-columns section{min-width:0}.snapshot{border:1px solid var(--border,#ddd);border-radius:10px;padding:10px;margin-top:7px}
.snapshot-row{display:flex;justify-content:space-between;gap:12px;padding:7px 0;border-bottom:1px solid rgba(127,127,127,.15);font-size:12px}
.snapshot-row:last-child{border-bottom:0}.snapshot-row span{opacity:.55}.snapshot-row strong{font-weight:600;text-align:right;overflow-wrap:anywhere}
.ids{display:grid;grid-template-columns:auto 1fr;gap:7px 12px;margin-top:16px;font-size:12px}.ids code{overflow-wrap:anywhere}
@media(max-width:700px){.conflict-filters,.snapshot-columns,.detail-grid{grid-template-columns:1fr}.conflict-card{padding:11px}}

.conflict-panel{margin-top:18px}.conflict-heading{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}
.conflict-filters{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:14px 0}
.conflict-filters select,.conflict-filters input{border:1px solid #ddd;border-radius:10px;padding:9px;background:#fff;color:inherit}
.conflict-summary{display:flex;gap:18px;padding:4px 0 12px;font-size:13px;opacity:.72}.conflict-list{display:grid;gap:8px}
.conflict-card{display:block;text-align:left;width:100%;padding:13px;border:1px solid #ddd;border-radius:12px;background:#fff;cursor:pointer;color:inherit}
.conflict-card:hover{border-color:#888}.conflict-card-top,.conflict-meta{display:flex;justify-content:space-between;align-items:center;gap:8px}
.provider-badge,.status-badge{font-size:11px;font-weight:700;padding:3px 7px;border-radius:999px}.provider-badge.google{background:#f1f4ff}.provider-badge.microsoft{background:#edf8f1}
.status-badge.open{background:#fff2d9}.status-badge.resolved{background:#eaf7ed}.conflict-title{font-weight:700;margin:9px 0 4px}.conflict-reason{font-size:13px;opacity:.72;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.conflict-meta{font-size:12px;opacity:.62;margin-top:9px}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.42);display:flex;align-items:center;justify-content:center;padding:20px;z-index:20}.modal.hidden{display:none}.modal-card{max-width:1000px;width:100%;max-height:90vh;overflow:auto;background:#fff;border-radius:18px;padding:22px;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.modal-head{display:flex;justify-content:space-between;align-items:flex-start}.modal-head button{border:0;background:transparent;font-size:28px;cursor:pointer}.eyebrow,.snapshot-title{font-size:11px;text-transform:uppercase;letter-spacing:.08em;opacity:.55;font-weight:700}
.detail-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:18px 0}.detail-grid div{padding:11px;border:1px solid #ddd;border-radius:10px}.detail-grid span{display:block;font-size:11px;opacity:.55;margin-bottom:4px}.reason-box{padding:12px;border-radius:10px;background:#f6f6f6;margin-bottom:16px}
.snapshot-columns{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.snapshot{border:1px solid #ddd;border-radius:10px;padding:10px;margin-top:7px}.snapshot-row{display:flex;justify-content:space-between;gap:12px;padding:7px 0;border-bottom:1px solid #eee;font-size:12px}.snapshot-row:last-child{border-bottom:0}.snapshot-row span{opacity:.55}.snapshot-row strong{font-weight:600;text-align:right;overflow-wrap:anywhere}.ids{display:grid;grid-template-columns:auto 1fr;gap:7px 12px;margin-top:16px;font-size:12px}.ids code{overflow-wrap:anywhere}
@media(max-width:700px){.conflict-filters,.snapshot-columns,.detail-grid{grid-template-columns:1fr}.conflict-heading{display:block}}
 .manual-actions{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0}.manual-actions button{padding:9px 12px;border:1px solid #ddd;border-radius:10px;background:#fff;cursor:pointer}.manual-actions .primary{background:#111;color:#fff;border-color:#111}

.merge-preview-card{max-width:1100px}.preview-note{padding:10px 12px;border-radius:10px;background:#f6f6f6;margin:14px 0;font-size:13px}
.merge-table{border:1px solid #ddd;border-radius:12px;overflow:auto}.merge-row{display:grid;grid-template-columns:130px 1fr 1fr 1fr;min-width:760px}.merge-row>div{padding:10px;border-right:1px solid #eee;border-bottom:1px solid #eee;font-size:12px;overflow-wrap:anywhere}.merge-row>div:last-child{border-right:0}.merge-header{background:#f7f7f7;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em}.merge-row.different{background:#fffaf0}.merged-value{font-weight:700;background:#f2f8f3}

.merge-edit{width:100%;box-sizing:border-box;border:1px solid #bbb;border-radius:8px;padding:7px;background:#fff;font:inherit;font-size:12px}.merge-edit:focus{outline:2px solid #aaa;outline-offset:1px}.merge-check{display:flex;gap:6px;align-items:center}.merge-check input{width:auto}

.merge-field-control{display:flex;flex-direction:column;gap:4px}.merge-field-control.invalid .merge-edit,.merge-edit.invalid{border:2px solid #c62828;background:#fff5f5}.field-error{min-height:16px;color:#b71c1c;font-size:11px;line-height:1.3}.merge-row.invalid{background:#fff5f5}.merge-row.invalid-range{background:#fff0f0}.stale-error{margin-bottom:12px}

#confirmMergeButton:disabled{opacity:.5;cursor:not-allowed}.merge-edit.invalid{border-color:#c62828}.merge-field-control.invalid .field-error{font-weight:600}
</style></head><body><div class="app"><aside class="nav"><div class="brand">AI Day Manager</div>
<button data-page="today">Heute</button><button data-page="calendar">Kalender</button><button data-page="tasks">Aufgaben</button><button data-page="ai">KI</button><button data-page="settings">Einstellungen</button></aside>
<main class="main" id="root"></main></div>
<script>
let me=null;
const state={page:'today',date:new Date().toISOString().slice(0,10)};
function loginScreen(){root.innerHTML='<div class="auth"><div class="card"><h1>AI Day Manager</h1><p class="muted">Dein persönlicher Tagesassistent.</p><div id="authError"></div><label>Name <small>(nur bei Registrierung)</small></label><input id="authName" placeholder="Dein Name"><label>E-Mail</label><input id="authEmail" type="email" placeholder="du@example.com"><label>Passwort</label><input id="authPassword" type="password" placeholder="Mindestens 10 Zeichen"><div class="composer"><button class="primary" onclick="authAction('login')">Anmelden</button><button onclick="authAction('signup')">Konto erstellen</button></div></div></div>'}
async function authAction(mode){const r=await fetch('/api/auth/'+mode,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:authName.value,email:authEmail.value,password:authPassword.value})});const d=await r.json();if(!r.ok){authError.innerHTML='<div class="error">'+esc(d.error||'Anmeldung fehlgeschlagen')+'</div>';return}me=d.user;render()}
async function bootAuth(){const r=await fetch('/api/auth/me');const d=await r.json();if(!d.user){loginScreen();return}me=d.user;render()}

const root=document.getElementById('root');
document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>{state.page=b.dataset.page;render()});
async function api(path,opt={}){const r=await fetch(path,{headers:{'content-type':'application/json'},...opt});return r.json()}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function logout(){await fetch('/api/auth/logout',{method:'POST'});me=null;loginScreen()}
async function render(){
 document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===state.page));
 if(state.page==='today')return today(); if(state.page==='tasks')return tasks(); if(state.page==='calendar')return calendar(); if(state.page==='ai')return ai(); settings()
}
async function today(){const d=await api('/api/day?date='+state.date);root.innerHTML='<div class="top"><div><h1>Guten Morgen ☀️</h1><div class="muted">Dein Tag ist vorbereitet.</div></div><span>'+state.date+' · '+esc(me?.name||'')+' · <button onclick="logout()">Abmelden</button></span></div><div class="grid"><section class="card"><h2>Dein Tagesplan</h2>'+((d.plan?.blocks||[]).map(b=>'<div class="plan"><div class="time">'+new Date(b.startTime).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+' – '+new Date(b.endTime).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+'</div><div><b>'+esc(b.title)+'</b><br><span class="muted">'+esc(b.type)+'</span></div></div>').join('')||'<div class="empty">Heute ist noch nichts geplant.</div>')+'</section><aside class="card"><h2>🎯 Top 3</h2>'+((d.top3||[]).map((x,i)=>'<div class="item"><b>'+(i+1)+'. '+esc(x.title)+'</b><br><span class="muted">'+x.priority+'</span></div>').join('')||'<div class="empty">Keine offenen Aufgaben.</div>')+'<h2>Freie Zeit</h2><div class="item">'+esc(d.freeMinutes??0)+' Minuten</div></aside></div>'}
async function tasks(){const d=await api('/api/tasks');root.innerHTML='<div class="top"><div><h1>Aufgaben</h1><div class="muted">Alles, was flexibel in deinen Tag integriert werden kann.</div></div></div><div class="card"><div class="composer"><input id="taskInput" placeholder="z.B. Ich muss heute 45 Minuten Steuerunterlagen machen"><button class="primary" onclick="send(document.getElementById(\\'taskInput\\').value)">Hinzufügen</button></div>'+((d.tasks||[]).map(t=>'<div class="item"><b>'+esc(t.title)+'</b> <span class="pill">'+t.priority+'</span><br><span class="muted">'+t.estimatedDurationMinutes+' min · '+t.schedulingMode+'</span></div>').join('')||'<div class="empty">Noch keine Aufgaben.</div>')+'</div>'}
async function calendar(){const d=await api('/api/day?date='+state.date);root.innerHTML='<div class="top"><div><h1>Kalender</h1><div class="muted">Timeline für '+state.date+'</div></div></div><div class="card">'+((d.events||[]).map(e=>'<div class="item"><b>'+esc(e.title)+'</b><br><span class="muted">'+new Date(e.startTime).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+' – '+new Date(e.endTime).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+'</span></div>').join('')||'<div class="empty">Keine festen Termine.</div>')+'</div>'}
async function ai(){root.innerHTML='<div class="top"><div><h1>KI-Assistent</h1><div class="muted">Sag mir einfach, was ansteht. Der Plan wird danach automatisch aktualisiert.</div></div></div><div class="card"><div class="composer"><input id="aiInput" placeholder="z.B. Morgen um 14 Uhr habe ich ein Bewerbungsgespräch"><button class="primary" onclick="send(document.getElementById(\\'aiInput\\').value)">Planen</button></div><div id="result"></div></div>'}
async function serializeMergeError(e:any){
  if(e?.code==='VALIDATION_ERROR') return {error:e.message,code:e.code,fieldErrors:e.fieldErrors||[]};
  return {error:e instanceof Error?e.message:'Resolution failed'};
}
function send(text){if(!text)return;const r=await api('/api/ai/command',{method:'POST',body:JSON.stringify({input:text,date:state.date})});const box=document.getElementById('result');if(box)box.innerHTML='<div class="'+(r.action==='REJECTED'?'notice':'success')+'" style="margin-top:15px">'+esc(r.message)+'</div>';if(r.action==='CREATED_TASK'||r.action==='CREATED_EVENT')setTimeout(()=>{state.page='today';render()},600)}
async function settings(){
 const d=await api('/api/preferences');
 root.innerHTML=`<div class="top"><div><h1>Einstellungen</h1><div class="muted">So soll dein Assistent deinen Tag organisieren.</div></div></div>
 <div class="card"><label>Arbeitsbeginn</label><input id="ws" type="time" value="${d.preferences.workStartTime}">
 <label>Arbeitsende</label><input id="we" type="time" value="${d.preferences.workEndTime}">
 <label>Autonomie</label><select id="auto"><option value="SUPPORTED">Unterstützt</option><option value="AUTOMATIC">Automatisch</option><option value="AUTONOMOUS">Autonom</option></select>
 <label>Standard-Puffer</label><input id="buf" type="text" value="${d.preferences.defaultBufferMinutes}">
 <br><button class="primary" onclick="savePrefs()">Speichern</button>
 <h2 style="margin-top:28px">Kalender verbinden</h2>
 <div class="item"><a href="/api/calendar/google/connect"><button>Google Calendar</button></a> <a href="/api/calendar/microsoft/connect"><button>Microsoft Outlook</button></a></div>
 <p class="muted">Bei „Automatisch“ werden neue oder verschobene Termine in verbundene Kalender geschrieben. Bei „Unterstützt“ bleiben externe Kalender schreibgeschützt.</p>
 </div>
 <div class="card conflict-panel"><div class="conflict-heading"><div><h2>Synchronisationskonflikte</h2><div class="muted">Nachvollziehbare Historie von Änderungen zwischen deinen Kalendern.</div></div><button onclick="loadConflicts()">Aktualisieren</button></div>
 <div class="conflict-filters">
  <select id="confProvider"><option value="">Alle Provider</option><option value="GOOGLE">Google</option><option value="MICROSOFT">Microsoft</option></select>
  <select id="confStatus"><option value="">Alle Status</option><option value="OPEN">Offen</option><option value="RESOLVED">Aufgelöst</option></select>
  <select id="confResolution"><option value="">Alle Auflösungen</option><option value="LOCAL_WINS">Lokal gewinnt</option><option value="EXTERNAL_WINS">Extern gewinnt</option><option value="DELETE_LOCAL">Lokal gelöscht</option><option value="DELETE_EXTERNAL">Extern gelöscht</option><option value="RETRY">Erneuter Versuch</option><option value="MANUAL">Manuell</option><option value="SKIPPED">Übersprungen</option></select>
  <input id="confSearch" placeholder="Konflikte durchsuchen …">
 </div>
 <div id="conflictSummary" class="conflict-summary"></div><div id="conflicts"><div class="muted">Wird geladen …</div></div></div>
 <div id="mergePreviewModal" class="modal hidden" onclick="if(event.target===this)closeMergePreview()"><div class="modal-card merge-preview-card">
<div class="modal-head"><div><div class="eyebrow">Merge-Vorschau</div><h2>Zusammengeführte Version prüfen</h2><div class="muted">Noch nichts wurde gespeichert.</div></div><button onclick="closeMergePreview()">×</button></div>
<div id="mergePreviewContent"></div>
<div class="manual-actions"><button onclick="closeMergePreview()">Abbrechen</button><button class="primary" id="confirmMergeButton">Merge übernehmen</button></div>
</div></div>
<div id="conflictModal" class="modal hidden" onclick="if(event.target===this)closeConflict()"><div class="modal-card">
  <div class="modal-head"><div><div class="eyebrow">Konfliktdetails</div><h2 id="confTitle">Synchronisationskonflikt</h2></div><button onclick="closeConflict()">×</button></div>
  <div id="confDetail"></div>
 </div></div>`;
 ['confProvider','confStatus','confResolution','confSearch'].forEach(id=>document.getElementById(id).addEventListener('input',renderConflicts));
 await loadConflicts();
}

function conflictLabel(v){return ({BOTH_CHANGED:'Beide Seiten geändert',EXTERNAL_DELETED:'Extern gelöscht',EXTERNAL_DELETED_LOCAL_CHANGED:'Extern gelöscht / lokal geändert',WRITE_FAILED:'Schreibfehler',LOCAL_DELETED_EXTERNAL_CHANGED:'Lokal gelöscht / extern geändert'})[v]||v}
function resolutionLabel(v){return ({LOCAL_WINS:'Lokal gewinnt',EXTERNAL_WINS:'Extern gewinnt',DELETE_LOCAL:'Lokal löschen',DELETE_EXTERNAL:'Extern löschen',RETRY:'Erneuter Versuch',MANUAL:'Manuell',SKIPPED:'Übersprungen',MERGED:'Zusammengeführt'})[v]||v}
function fmt(v){return v?new Date(v).toLocaleString('de-DE'):'—'}
function conflictStatus(c){return c.resolvedAt?'RESOLVED':'OPEN'}
function snapshotHtml(o){if(!o)return '<span class="muted">Kein Snapshot vorhanden</span>';return Object.entries(o).map(([k,v])=>`<div class="snapshot-row"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join('')}
function renderConflicts(){
 const p=document.getElementById('confProvider')?.value||'', st=document.getElementById('confStatus')?.value||'', r=document.getElementById('confResolution')?.value||'', q=(document.getElementById('confSearch')?.value||'').toLowerCase();
 const rows=window.conflictData.filter(c=>(!p||c.provider===p)&&(!st||conflictStatus(c)===st)&&(!r||c.resolution===r)&&(!q||`${c.provider} ${c.type} ${c.resolution} ${c.reason}`.toLowerCase().includes(q)));
 const open=window.conflictData.filter(c=>!c.resolvedAt).length;
 document.getElementById('conflictSummary').innerHTML=`<span><b>${rows.length}</b> angezeigt</span><span><b>${open}</b> offen</span><span><b>${window.conflictData.length}</b> gesamt</span>`;
 document.getElementById('conflicts').innerHTML=rows.length?`<div class="conflict-list">${rows.map(c=>`<button class="conflict-card" onclick="showConflict('${c.id}')"><div class="conflict-card-top"><span class="provider-badge ${c.provider.toLowerCase()}">${c.provider}</span><span class="status-badge ${conflictStatus(c).toLowerCase()}">${conflictStatus(c)==='OPEN'?'Offen':'Aufgelöst'}</span></div><div class="conflict-title">${esc(conflictLabel(c.type))}</div><div class="conflict-reason">${esc(c.reason)}</div><div class="conflict-meta"><span>${esc(resolutionLabel(c.resolution))}</span><span>${fmt(c.detectedAt)}</span></div></button>`).join('')}</div>`:'<div class="empty">Keine Konflikte für diese Filter.</div>';
}
async function loadConflicts(){
 const r=await fetch('/api/calendar/conflicts'); const x=await r.json(); window.conflictData=x.conflicts||[]; renderConflicts();
}
function showConflict(id){
 const c=window.conflictData.find(x=>x.id===id); if(!c)return;
 document.getElementById('confTitle').textContent=conflictLabel(c.type);
 document.getElementById('confDetail').innerHTML=`<div class="detail-grid"><div><span>Provider</span><b>${esc(c.provider)}</b></div><div><span>Status</span><b>${conflictStatus(c)==='OPEN'?'Offen':'Aufgelöst'}</b></div><div><span>Auflösung</span><b>${esc(resolutionLabel(c.resolution))}</b></div><div><span>Erkannt</span><b>${fmt(c.detectedAt)}</b></div><div><span>Lokale Änderung</span><b>${fmt(c.localUpdatedAt)}</b></div><div><span>Externe Änderung</span><b>${fmt(c.externalUpdatedAt)}</b></div></div><div class="reason-box">${esc(c.reason)}</div><div class="manual-actions">
<button class="primary" onclick="resolveConflict('${c.id}','LOCAL_WINS')">Lokale Version übernehmen</button>
<button onclick="resolveConflict('${c.id}','EXTERNAL_WINS')">Externe Version übernehmen</button>
<button onclick="openMergePreview('${c.id}')">Beide zusammenführen</button>
</div><div id="resolveStatus" class="muted"></div><div class="snapshot-columns"><section><div class="snapshot-title">Gemeinsame Basis</div><div class="snapshot">${snapshotHtml(c.baseLocalSnapshot||c.baseExternalSnapshot)}</div></section><section><div class="snapshot-title">Lokaler Snapshot</div><div class="snapshot">${snapshotHtml(c.localSnapshot)}</div></section><section><div class="snapshot-title">Externer Snapshot</div><div class="snapshot">${snapshotHtml(c.externalSnapshot)}</div></section></div><div class="ids"><span>Lokale Event-ID</span><code>${esc(c.localEventId||'—')}</code><span>Externe Event-ID</span><code>${esc(c.externalEventId||'—')}</code></div>`;
 document.getElementById('conflictModal').classList.remove('hidden');
}
async function openMergePreview(id){
 const modal=document.getElementById('mergePreviewModal'), content=document.getElementById('mergePreviewContent');
 content.innerHTML='<div class="muted">Vorschau wird berechnet …</div>';modal.classList.remove('hidden');
 const r=await fetch('/api/calendar/conflicts/'+encodeURIComponent(id)+'/preview');const d=await r.json();
 if(!r.ok){content.innerHTML='<div class="error">'+esc(d.error||'Vorschau fehlgeschlagen')+'</div>';return}
 const labels={title:'Titel',description:'Beschreibung',startTime:'Startzeit',endTime:'Endzeit',location:'Ort',isFixed:'Fixiert'};
 content.innerHTML=`<div class="preview-note">Unterschiedliche Felder sind hervorgehoben. Das Merge-Ergebnis ist editierbar; Änderungen werden erst mit „Merge übernehmen“ gespeichert.</div>
 <div class="merge-table"><div class="merge-row merge-header"><div>Feld</div><div>Lokal</div><div>Extern</div><div>Ergebnis (bearbeitbar)</div></div>
 ${d.preview.fields.map(f=>`<div class="merge-row ${f.changed?'different':''}">
 <div><b>${labels[f.field]||f.field}</b></div>
 <div>${formatPreviewValue(f.field,f.local)}</div>
 <div>${formatPreviewValue(f.field,f.external)}</div>
 <div class="merged-value">${editablePreviewField(f)}</div>
 </div>`).join('')}</div>`;
 document.getElementById('confirmMergeButton').onclick=()=>confirmEditableMerge(id);
}
function formatPreviewValue(field,value){
 if(value===null||value===undefined||value==='')return '<span class="muted">—</span>';
 if(field==='startTime'||field==='endTime')return esc(fmt(value));
 if(field==='isFixed')return value?'Ja':'Nein';
 return esc(String(value));
}
function editablePreviewField(f){
 const value=f.merged??'';
 let control='';
 if(f.field==='description') control=`<textarea class="merge-edit" data-merge-field="${f.field}" rows="3">${esc(String(value))}</textarea>`;
 else if(f.field==='isFixed') control=`<label class="merge-check"><input type="checkbox" data-merge-field="${f.field}" ${value?'checked':''}> Ja</label>`;
 else if(f.field==='startTime'||f.field==='endTime') control=`<input class="merge-edit" data-merge-field="${f.field}" type="datetime-local" value="${toDatetimeLocal(value)}">`;
 else control=`<input class="merge-edit" data-merge-field="${f.field}" type="text" value="${escAttr(String(value))}">`;
 return `<div class="merge-field-control">${control}<div class="field-error" data-error-for="${f.field}"></div></div>`;
}
function clientMergeErrors(){
 const errors=[];
 const get=(field)=>document.querySelector(`#mergePreviewContent [data-merge-field="${field}"]`);
 const title=get('title'), desc=get('description'), loc=get('location'), start=get('startTime'), end=get('endTime');
 if(title && !title.value.trim()) errors.push({field:'title',code:'REQUIRED',message:'Der Titel darf nicht leer sein.'});
 if(title && title.value.length>500) errors.push({field:'title',code:'TOO_LONG',message:'Der Titel ist zu lang.'});
 if(desc && desc.value.length>10000) errors.push({field:'description',code:'TOO_LONG',message:'Die Beschreibung ist zu lang.'});
 if(loc && loc.value.length>1000) errors.push({field:'location',code:'TOO_LONG',message:'Der Ort ist zu lang.'});
 let sd=start?.value?new Date(start.value):null, ed=end?.value?new Date(end.value):null;
 if(start && start.value && Number.isNaN(sd?.getTime())) errors.push({field:'startTime',code:'INVALID_TIME',message:'Startzeit ist ungültig.'});
 if(end && end.value && Number.isNaN(ed?.getTime())) errors.push({field:'endTime',code:'INVALID_TIME',message:'Endzeit ist ungültig.'});
 if(sd&&!Number.isNaN(sd.getTime())&&ed&&!Number.isNaN(ed.getTime())){
   if(ed<=sd){
     errors.push({field:'startTime',code:'INVALID_RANGE',message:'Die Endzeit muss nach der Startzeit liegen.'});
     errors.push({field:'endTime',code:'INVALID_RANGE',message:'Die Endzeit muss nach der Startzeit liegen.'});
   }else if(ed-sd>24*60*60*1000){
     errors.push({field:'startTime',code:'TOO_LONG_RANGE',message:'Der Zeitraum darf höchstens 24 Stunden dauern.'});
     errors.push({field:'endTime',code:'TOO_LONG_RANGE',message:'Der Zeitraum darf höchstens 24 Stunden dauern.'});
   }
 }
 return errors;
}
function showClientMergeErrors(){
 const errors=clientMergeErrors();
 clearMergeErrors();
 if(errors.length) showMergeErrors(errors);
 const button=document.getElementById('confirmMergeButton');
 if(button) button.disabled=errors.length>0;
 return errors;
}
function bindMergeLiveValidation(){
 document.querySelectorAll('#mergePreviewContent [data-merge-field]').forEach(el=>{
   el.addEventListener('input',showClientMergeErrors);
   el.addEventListener('change',showClientMergeErrors);
 });
 showClientMergeErrors();
}
function clearMergeErrors(){
 document.querySelectorAll('#mergePreviewContent .merge-field-control').forEach(x=>x.classList.remove('invalid'));
 document.querySelectorAll('#mergePreviewContent .merge-edit').forEach(x=>x.classList.remove('invalid'));
 document.querySelectorAll('#mergePreviewContent .field-error').forEach(x=>x.textContent='');
 document.querySelectorAll('#mergePreviewContent .merge-row.invalid-range').forEach(x=>x.classList.remove('invalid-range'));
}
function showMergeErrors(errors){
 clearMergeErrors();
 const byField={};
 for(const e of (errors||[])){
   (byField[e.field] ||= []).push(e);
   const target=document.querySelector(`#mergePreviewContent [data-error-for="${e.field}"]`);
   if(target) target.textContent=byField[e.field].map(x=>x.message).join(' ');
   const control=document.querySelector(`#mergePreviewContent [data-merge-field="${e.field}"]`);
   if(control) control.classList.add('invalid');
   const row=control?.closest('.merge-row');
   if(row) row.classList.add('invalid');
 }
 const timeRange=(errors||[]).some(e=>e.code==='INVALID_RANGE'||e.code==='TOO_LONG_RANGE');
 if(timeRange){
   ['startTime','endTime'].forEach(field=>{
     const control=document.querySelector(`#mergePreviewContent [data-merge-field="${field}"]`);
     control?.closest('.merge-row')?.classList.add('invalid-range');
   });
 }
 const first=document.querySelector('#mergePreviewContent .merge-edit.invalid');
 first?.focus();
}

function escAttr(v){return esc(v).replace(/"/g,'&quot;')}
function toDatetimeLocal(v){
 if(!v)return '';
 const d=new Date(v); if(Number.isNaN(d.getTime()))return '';
 const pad=n=>String(n).padStart(2,'0');
 return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
async function confirmEditableMerge(id,expectedVersion){
 clearMergeErrors();
 if(showClientMergeErrors().length)return;
 const overrides={};
 document.querySelectorAll('#mergePreviewContent [data-merge-field]').forEach(el=>{
   const field=el.getAttribute('data-merge-field');
   if(el.type==='checkbox') overrides[field]=el.checked;
   else if(el.type==='datetime-local') overrides[field]=el.value?new Date(el.value).toISOString():null;
   else overrides[field]=el.value;
 });
 if(!confirm('Die bearbeitete Merge-Version jetzt übernehmen?'))return;
 const r=await fetch('/api/calendar/conflicts/'+encodeURIComponent(id)+'/resolve',{
   method:'POST',headers:{'content-type':'application/json'},
   body:JSON.stringify({choice:'MERGED',overrides,expectedVersion})
 });
 const d=await r.json();
 if(!r.ok){
   if(d.code==='VALIDATION_ERROR'){showMergeErrors(d.fieldErrors);return;}
   if((d.error||'').includes('veraltet')){
     document.getElementById('mergePreviewContent').insertAdjacentHTML('afterbegin',`<div class="error stale-error">${esc(d.error)}</div>`);
     return;
   }
   document.getElementById('mergePreviewContent').insertAdjacentHTML('afterbegin',`<div class="error">${esc(d.error||'Auflösung fehlgeschlagen')}</div>`);
   return;
 }
 closeMergePreview();closeConflict();await renderConflicts();
}

function closeMergePreview(){document.getElementById('mergePreviewModal').classList.add('hidden')}
async function resolveConflict(id,choice,overrides={}){
 const labels={LOCAL_WINS:'Lokale Version übernehmen',EXTERNAL_WINS:'Externe Version übernehmen',MERGED:'Beide zusammenführen'};
 if(choice==='MERGED'&&!confirm('Merge jetzt übernehmen? Die Vorschau wurde bereits angezeigt.'))return;
 if(choice!=='MERGED'&&!confirm(labels[choice]+'? Die gewählte Version wird zurück in den verbundenen Kalender geschrieben.'))return;
 const el=document.getElementById('resolveStatus');el.textContent='Wird aufgelöst …';
 const r=await fetch('/api/calendar/conflicts/'+encodeURIComponent(id)+'/resolve',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({choice,overrides})});
 const d=await r.json();if(!r.ok){el.textContent=d.error||'Auflösung fehlgeschlagen';return}
 el.textContent='Konflikt erfolgreich aufgelöst.';await loadConflicts();showConflict(id);
}
function closeConflict(){document.getElementById('conflictModal').classList.add('hidden')}

async function savePrefs(){await api('/api/preferences',{method:'POST',body:JSON.stringify({workStartTime:ws.value,workEndTime:we.value,autonomyLevel:auto.value,defaultBufferMinutes:Number(buf.value)})});alert('Gespeichert');}
bootAuth();
</script></body></html>`;

function send(res,status,data,contentType='application/json'){
  res.writeHead(status,{'content-type':contentType,'cache-control':'no-store'});res.end(typeof data==='string'?data:JSON.stringify(data));
}
async function body(req){let s='';for await(const c of req)s+=c;return s?JSON.parse(s):{}}
const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url??'/',`http://${req.headers.host??'localhost'}`);
    if(req.method==='GET'&&u.pathname==='/api/auth/me'){
      const user=await currentUser(req); return send(res,200,{user});
    }
    if(req.method==='GET'&&u.pathname==='/api/calendar/google/connect'){
      const cu=await currentUser(req); requireUser(cu);
      return res.writeHead(302,{location:await beginOAuth(cu.id,'GOOGLE')}).end();
    }
    if(req.method==='GET'&&u.pathname==='/api/calendar/microsoft/connect'){
      const cu=await currentUser(req); requireUser(cu);
      return res.writeHead(302,{location:await beginOAuth(cu.id,'MICROSOFT')}).end();
    }
    if(req.method==='GET'&&u.pathname==='/api/calendar/google/callback'){
      const code=u.searchParams.get('code'),state=u.searchParams.get('state');
      if(!code||!state)return send(res,400,{error:'OAuth callback missing code/state'});
      await finishOAuth('GOOGLE',state,code); return res.writeHead(302,{location:'/'}).end();
    }
    if(req.method==='GET'&&u.pathname==='/api/calendar/microsoft/callback'){
      const code=u.searchParams.get('code'),state=u.searchParams.get('state');
      if(!code||!state)return send(res,400,{error:'OAuth callback missing code/state'});
      await finishOAuth('MICROSOFT',state,code); return res.writeHead(302,{location:'/'}).end();
    }
    if(req.method==='POST'&&u.pathname==='/api/auth/signup'){
      const p=await body(req); const result=await auth.signup(String(p.email??''),String(p.password??''),String(p.name??''));
      setSession(res,result.token); return send(res,201,{user:result.user});
    }
    if(req.method==='POST'&&u.pathname==='/api/auth/login'){
      const p=await body(req); const result=await auth.login(String(p.email??''),String(p.password??''));
      setSession(res,result.token); return send(res,200,{user:result.user});
    }
    if(req.method==='POST'&&u.pathname==='/api/auth/logout'){
      await auth.logout((req.headers.cookie??'').split(';').map(v=>v.trim()).find(v=>v.startsWith('ai_day_session='))?.split('=')[1]);
      clearSession(res); return send(res,200,{ok:true});
    }
    if(req.method==='GET'&&u.pathname==='/'){return send(res,200,html,'text/html; charset=utf-8')}
    const user=await currentUser(req);
    requireUser(user);
    const USER_ID=user.id;
    if(req.method==='GET'&&u.pathname==='/api/calendar/connections'){
      const connections=await new CalendarConnectionRepository(prisma).list(USER_ID);
      return send(res,200,{connections});
    }
    if(req.method==='GET'&&u.pathname==='/api/calendar/conflicts'){
      const { ConflictRepository }=await import('./calendar/conflict-resolution.js');
      let conflicts=await new ConflictRepository(prisma).list(USER_ID);
      const provider=u.searchParams.get('provider'), resolution=u.searchParams.get('resolution'), status=u.searchParams.get('status');
      if(provider) conflicts=conflicts.filter(c=>c.provider===provider);
      if(resolution) conflicts=conflicts.filter(c=>c.resolution===resolution);
      if(status==='OPEN') conflicts=conflicts.filter(c=>!c.resolvedAt);
      if(status==='RESOLVED') conflicts=conflicts.filter(c=>!!c.resolvedAt);
      return send(res,200,{conflicts});
    }
    if(req.method==='GET'&&/^\/api\/calendar\/conflicts\/[^/]+\/preview$/.test(u.pathname)){
      const id=u.pathname.split('/')[4];
      const { ManualConflictService }=await import('./calendar/manual-conflict-service.js');
      try{return send(res,200,{preview:await new ManualConflictService().preview(USER_ID,id)});}
      catch(e){return send(res,400,{error:e instanceof Error?e.message:'Preview failed'});}
    }
    if(req.method==='POST'&&/^\/api\/calendar\/conflicts\/[^/]+\/resolve$/.test(u.pathname)){
      const id=u.pathname.split('/')[4]; const p=await body(req); const choice=String(p.choice??'');
      if(!['LOCAL_WINS','EXTERNAL_WINS','MERGED'].includes(choice))return send(res,400,{error:'Invalid resolution choice'});
      const { ManualConflictService }=await import('./calendar/manual-conflict-service.js');
      try{return send(res,200,{result:await new ManualConflictService().resolve(USER_ID,id,choice as any)});}
      catch(e){return send(res,400,{error:e instanceof Error?e.message:'Conflict resolution failed'});}
    }
    if(req.method==='GET'&&u.pathname==='/api/tasks')return send(res,200,{tasks:await app['tasks'].list(USER_ID)});
    if(req.method==='GET'&&u.pathname==='/api/preferences')return send(res,200,{preferences:await app['preferences'].get(USER_ID)});
    if(req.method==='POST'&&u.pathname==='/api/preferences'){
      const p=await body(req);const current=await app['preferences'].get(USER_ID);
      return send(res,200,{preferences:await app['preferences'].set(USER_ID,{...current,...p})});
    }
    if(req.method==='GET'&&u.pathname==='/api/day'){
      const date=u.searchParams.get('date')??new Date().toISOString().slice(0,10);
      const plan=await app.recalculate(USER_ID,date);
      const events=await await app['calendar'].getDay(USER_ID,new Date(`${date}T00:00:00Z`),new Date(`${date}T23:59:59Z`));
      const tasks=(await app['tasks'].list(USER_ID)).filter(t=>t.status==='OPEN');
      return send(res,200,{plan,events,top3:tasks.sort((a,b)=>a.priority.localeCompare(b.priority)).slice(0,3),freeMinutes:Math.max(0,plan.blocks.filter(b=>b.type==='FREE_TIME').reduce((n,b)=>n+(new Date(b.endTime).getTime()-new Date(b.startTime).getTime())/60000,0))});
    }
    if(req.method==='POST'&&u.pathname==='/api/ai/command'){
      const p=await body(req); if(typeof p.input!=='string'||!p.input.trim())return send(res,400,{error:'input is required'});
      const result=await app.handleNaturalLanguage(USER_ID,p.input,String(p.date??new Date().toISOString().slice(0,10)));
      return send(res,200,result);
    }
    return send(res,404,{error:'Not found'});
  }catch(e){return send(res,400,{error:e instanceof Error?e.message:'Request failed'})}
});
server.listen(PORT,()=>console.log(`AI Day Manager listening on http://localhost:${PORT}`));
