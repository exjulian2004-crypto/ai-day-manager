import { strict as assert } from 'node:assert';
import { existsSync, readFileSync } from 'node:fs';

assert.ok(existsSync('prisma/schema.prisma'), 'Prisma schema missing');
assert.ok(existsSync('src/server.ts'), 'HTTP server missing');
assert.ok(existsSync('src/application/application-service.ts'), 'Application service missing');
assert.ok(existsSync('src/planning/planning-engine.ts'), 'Planning engine missing');
assert.ok(existsSync('src/auth/auth-service.ts'), 'Auth service missing');
assert.ok(existsSync('src/calendar/manual-conflict-service.ts'), 'Conflict service missing');

const env=readFileSync('.env.example','utf8');
for(const key of ['DATABASE_URL','TOKEN_ENCRYPTION_KEY','GOOGLE_CLIENT_ID','MICROSOFT_CLIENT_ID']){
  assert.ok(env.includes(key), `Missing environment variable template: ${key}`);
}
console.log('release smoke checks passed');
